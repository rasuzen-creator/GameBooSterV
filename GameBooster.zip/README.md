# Nexus Turbo 3.0 (Android)

A refreshed source project based on the supplied GameBooster Kotlin Android project.

## Changes in this refresh
- Nexus Turbo branding on the app label and project name; app version 3.0.
- Game cards now include a dedicated **GAME BOOST** panel before launch.
- Premium card and Promocode entry screen.
- Promo code `NexusTurboHappyBirthday` locally grants Lifetime Premium once per device.
- Premium-locked tiles for Extreme profile and game-FPS feature; unlocked game-FPS tile explains platform limitations instead of showing fake numbers.
- Nexus UI FPS test measures the app's own frame callbacks for five seconds and explicitly does not represent a game's FPS.
- Gaming profile actions, touch test, storage analyzer, cache-clearing helper (opens selected game's Android App Info), and boost history.
- Boost history locally records the last 12 boost results.
- GitHub Actions workflow builds a debug APK and uploads it as an artifact.

## Build
Open this folder in Android Studio and let Gradle sync, then Build > Build APK.

Or on GitHub, push the project to a repository and run the **Nexus Turbo Android Build** workflow. The resulting APK is available in Actions artifacts.

## Important limitations
- The promo code currently unlocks Premium locally on a device. A true **first five users worldwide** claim limit cannot be securely enforced in a client-only APK. It needs a backend (e.g. Firebase/Firestore transaction or a small API) that atomically records five redemptions and issues claim tokens.
- Android restricts apps from clearing other apps' caches directly. The helper guides users to the selected game's App Info screen; select *Clear cache*, not *Clear data*.
- Ordinary apps cannot reliably read a game's true rendered FPS on every Android device. The built-in overlay reports the screen/app frame callback rate. The premium Game FPS panel is intentionally honest about hardware/OS/root/Shizuku limitations and does not fabricate a value.
- BOOST may have limited impact on Android versions that restrict background-process management. It cannot promise a fixed FPS increase.

## Version
- `versionCode`: 3
- `versionName`: 3.0
