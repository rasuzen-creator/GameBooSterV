package uz.rasuzen.gamebooster

import android.app.ActivityManager
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.graphics.drawable.Drawable

class AppEntry(val pkg: String, val label: String, val icon: Drawable, val isGame: Boolean)

object Booster {

    private val knownGamePrefixes = listOf(
        "com.tencent.ig", "com.pubg", "com.tencent.tmgp", "com.activision", "com.mojang", "com.roblox",
        "com.supercell", "com.miHoYo", "com.HoYoverse", "com.garena", "com.dts.freefire", "com.epicgames",
        "com.ea.", "com.gameloft", "com.king.", "com.kiloo", "com.imangi", "com.innersloth", "com.riotgames",
        "com.netease", "com.proximabeta", "com.levelinfinite", "com.krafton", "com.vng", "com.mobile.legends",
        "com.moonton", "com.nianticlabs", "com.ubisoft", "com.zynga", "com.playrix", "com.nexon", "com.mihoyo"
    )

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("booster", Context.MODE_PRIVATE)

    fun games(ctx: Context): Set<String> = HashSet(prefs(ctx).getStringSet("games", emptySet()) ?: emptySet())

    fun saveGames(ctx: Context, set: Set<String>) {
        prefs(ctx).edit().putStringSet("games", HashSet(set)).apply()
    }

    fun flag(ctx: Context, key: String, def: Boolean): Boolean = prefs(ctx).getBoolean(key, def)

    fun setFlag(ctx: Context, key: String, v: Boolean) {
        prefs(ctx).edit().putBoolean(key, v).apply()
    }

    fun label(ctx: Context, pkg: String): String = try {
        ctx.packageManager.getApplicationLabel(ctx.packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (e: Exception) {
        pkg
    }

    fun icon(ctx: Context, pkg: String): Drawable? = try {
        ctx.packageManager.getApplicationIcon(pkg)
    } catch (e: Exception) {
        null
    }

    fun launchables(ctx: Context): List<String> {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return ctx.packageManager.queryIntentActivities(i, 0)
            .map { it.activityInfo.packageName }
            .distinct()
            .filter { it != ctx.packageName }
    }

    fun loadApps(ctx: Context): List<AppEntry> {
        val pm = ctx.packageManager
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(i, 0)
            .filter { it.activityInfo.packageName != ctx.packageName }
            .distinctBy { it.activityInfo.packageName }
            .map {
                val ai = it.activityInfo.applicationInfo
                @Suppress("DEPRECATION")
                val game = ai.category == ApplicationInfo.CATEGORY_GAME ||
                    (ai.flags and ApplicationInfo.FLAG_IS_GAME) != 0 ||
                    knownGamePrefixes.any { p -> it.activityInfo.packageName.startsWith(p) }
                AppEntry(it.activityInfo.packageName, it.loadLabel(pm).toString(), it.loadIcon(pm), game)
            }
            .sortedBy { it.label.lowercase() }
    }

    fun availMb(ctx: Context): Long {
        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        return mi.availMem / 1048576
    }

    /** Fon jarayonlarni to'xtatadi. keep — tegilmaydigan paket (o'yin). */
    fun kill(ctx: Context, keep: String?): Int {
        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val list = launchables(ctx).filter { it != keep }
        list.forEach {
            try {
                am.killBackgroundProcesses(it)
            } catch (e: Throwable) {
            }
        }
        return list.size
    }

    fun dndGranted(ctx: Context): Boolean =
        ctx.getSystemService(NotificationManager::class.java).isNotificationPolicyAccessGranted

    fun dndOn(ctx: Context): Boolean =
        ctx.getSystemService(NotificationManager::class.java).currentInterruptionFilter != NotificationManager.INTERRUPTION_FILTER_ALL

    fun setDnd(ctx: Context, enable: Boolean): Boolean {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        if (!nm.isNotificationPolicyAccessGranted) return false
        nm.setInterruptionFilter(
            if (enable) NotificationManager.INTERRUPTION_FILTER_PRIORITY else NotificationManager.INTERRUPTION_FILTER_ALL
        )
        return true
    }
}
