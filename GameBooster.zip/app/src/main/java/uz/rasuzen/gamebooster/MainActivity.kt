package uz.rasuzen.gamebooster

import android.Manifest
import android.animation.ValueAnimator
import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Shader
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.TextUtils
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import kotlin.math.roundToInt

class MainActivity : Activity() {

    private val h = Handler(Looper.getMainLooper())
    private lateinit var host: FrameLayout
    private val pageViews = ArrayList<View>()
    private val pageContents = ArrayList<LinearLayout>()
    private var current = -1

    private val navIcons = ArrayList<ImageView>()
    private val navLabels = ArrayList<TextView>()
    private val navPills = ArrayList<View>()

    // Bosh sahifa
    private lateinit var gauge: GaugeView
    private lateinit var boostBtn: BoostButton
    private lateinit var resultText: TextView
    private lateinit var ramVal: TextView
    private lateinit var ramBar: BarView
    private lateinit var tempVal: TextView
    private lateinit var tempBar: BarView
    private lateinit var batVal: TextView
    private lateinit var batBar: BarView
    private lateinit var homeRow: LinearLayout
    private lateinit var tipsBox: LinearLayout
    private lateinit var overlayToggle: ToggleView
    private var liveAnim: ValueAnimator? = null
    private var boosting = false
    private var lastScore = -1
    private var lastTips = ""

    // O'yinlar
    private lateinit var gamesGrid: LinearLayout
    private var premiumUnlocked = false

    // Qurilma
    private lateinit var deviceLoading: TextView
    private var deviceText = ""

    // Asboblar
    private lateinit var dndToggle: ToggleView
    private val permUpdaters = ArrayList<() -> Unit>()
    private val pingViews = ArrayList<Pair<TextView, TextView>>()
    private lateinit var pingBtn: TextView
    private var pinging = false
    private val pingTargets = listOf("Google" to "8.8.8.8", "Cloudflare" to "1.1.1.1", "Yandex" to "77.88.8.8")

    private val homeTick = object : Runnable {
        override fun run() {
            if (current == 0 && !boosting) refreshHome()
            h.postDelayed(this, 3000)
        }
    }

    // ------------------------------------------------------------------ lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = C.BG
        window.navigationBarColor = C.BG

        val rootCol = vbox(0).apply { setBackgroundColor(C.BG) }
        host = FrameLayout(this)
        rootCol.add(host, MATCH, 0, weight = 1f)
        rootCol.add(buildNav(), MATCH, WRAP)
        setContentView(rootCol)
        premiumUnlocked = getSharedPreferences("nexus_premium", MODE_PRIVATE).getBoolean("premium", false)

        val pages = listOf(buildHome(), buildGames(), buildDevice(), buildTools())
        for ((v, content) in pages) {
            v.visibility = View.GONE
            host.addView(v, FrameLayout.LayoutParams(MATCH, MATCH))
            pageViews.add(v)
            pageContents.add(content)
        }
        renderGames()
        select(0)
        loadDeviceInfo()
    }

    override fun onResume() {
        super.onResume()
        overlayToggle.toggleTo(OverlayService.running, false)
        dndToggle.toggleTo(Booster.dndOn(this), false)
        permUpdaters.forEach { it() }
        h.removeCallbacks(homeTick)
        h.postDelayed(homeTick, 3000)
    }

    override fun onPause() {
        super.onPause()
        h.removeCallbacks(homeTick)
    }

    override fun onDestroy() {
        liveAnim?.cancel()
        super.onDestroy()
    }

    // ------------------------------------------------------------------ navigatsiya

    private fun buildNav(): View {
        val bar = hbox().apply { setPadding(dp(6), 0, dp(6), 0) }
        val items = listOf(
            Pair(R.drawable.ic_home, "Bosh sahifa"),
            Pair(R.drawable.ic_game, "O'yinlar"),
            Pair(R.drawable.ic_phone, "Qurilma"),
            Pair(R.drawable.ic_tools, "Asboblar")
        )
        items.forEachIndexed { idx, (res, label) ->
            val box = vbox(0).apply {
                gravity = Gravity.CENTER
                setPadding(0, dp(9), 0, dp(9))
            }
            val frame = FrameLayout(this)
            val pill = View(this).apply {
                background = roundedBg(withAlpha(C.GREEN, 40), 16f)
                scaleX = 0f
                alpha = 0f
            }
            frame.addView(pill, FrameLayout.LayoutParams(dp(56), dp(30), Gravity.CENTER))
            val icon = ImageView(this).apply {
                try {
                    setImageResource(res)
                } catch (e: Throwable) {
                }
                setColorFilter(C.MUTED)
            }
            frame.addView(icon, FrameLayout.LayoutParams(dp(22), dp(22), Gravity.CENTER))
            box.add(frame, dp(56), dp(30))
            val t = tv(label, 11f, C.MUTED, true).apply { gravity = Gravity.CENTER }
            box.add(t, WRAP, WRAP, t = 3)
            box.pressable { select(idx) }
            bar.add(box, 0, WRAP, weight = 1f)
            navIcons.add(icon)
            navLabels.add(t)
            navPills.add(pill)
        }
        val wrap = vbox(0).apply { setBackgroundColor(C.SURFACE) }
        wrap.add(View(this).apply { setBackgroundColor(C.STROKE) }, MATCH, 1)
        wrap.add(bar)
        return wrap
    }

    private fun styleNav() {
        for (i in navIcons.indices) {
            val sel = i == current
            val col = if (sel) C.GREEN else C.MUTED
            navIcons[i].setColorFilter(col)
            navLabels[i].setTextColor(col)
            navPills[i].animate().alpha(if (sel) 1f else 0f).scaleX(if (sel) 1f else 0f).setDuration(240).start()
            val s = if (sel) 1.15f else 1f
            navIcons[i].animate().scaleX(s).scaleY(s).setDuration(240).start()
        }
    }

    private fun select(i: Int) {
        if (i == current) return
        val old = current
        current = i
        styleNav()
        pageViews.forEachIndexed { j, v ->
            if (j != i && j != old) {
                v.animate().cancel(); v.visibility = View.GONE
            }
        }
        if (old >= 0) {
            val ov = pageViews[old]
            ov.animate().cancel()
            ov.animate().alpha(0f).setDuration(140).withEndAction {
                if (current != old) ov.visibility = View.GONE
            }.start()
        }
        val nv = pageViews[i]
        nv.animate().cancel()
        nv.visibility = View.VISIBLE
        nv.alpha = 0f
        nv.animate().alpha(1f).setDuration(240).setStartDelay(60).start()
        (nv as? ScrollView)?.scrollTo(0, 0)
        staggerIn(pageContents[i], 40)
        if (i == 0) refreshHome()
    }

    // ------------------------------------------------------------------ umumiy bo'laklar

    private fun newPage(): Pair<ScrollView, LinearLayout> {
        val col = vbox(0).apply { setPadding(dp(18), dp(22), dp(18), dp(26)) }
        val sv = ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            addView(col, ViewGroup.LayoutParams(MATCH, WRAP))
        }
        return sv to col
    }

    private fun header(col: LinearLayout, title: String, sub: String, right: View? = null, gradient: Boolean = false) {
        val row = hbox()
        val left = vbox(0)
        val t = tv(title, 28f, C.TEXT, true)
        if (gradient) {
            t.paint.shader = LinearGradient(0f, 0f, t.paint.measureText(title), 0f, C.GREEN, C.CYAN, Shader.TileMode.CLAMP)
        }
        left.add(t, WRAP, WRAP)
        left.add(tv(sub, 13f, C.MUTED), WRAP, WRAP, t = 5)
        row.add(left, 0, WRAP, weight = 1f)
        if (right != null) row.add(right, WRAP, WRAP)
        col.add(row, b = 18)
    }

    private fun sectionTitle(text: String): TextView = tv(text, 16f, C.TEXT, true)

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    // ------------------------------------------------------------------ BOSH SAHIFA

    private fun statCard(title: String): Triple<LinearLayout, TextView, BarView> {
        val c = card(12)
        c.add(tv(title, 10f, C.MUTED, true).apply { letterSpacing = 0.1f })
        val v = tv("--", 18f, C.TEXT, true)
        c.add(v, WRAP, WRAP, t = 7)
        val bar = BarView(this)
        c.add(bar, MATCH, dp(5), t = 11)
        return Triple(c, v, bar)
    }

    private fun buildHome(): Pair<View, LinearLayout> {
        val (sv, col) = newPage()

        val live = chip("● LIVE", C.GREEN)
        liveAnim = ValueAnimator.ofFloat(1f, 0.35f).apply {
            duration = 900
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.REVERSE
            addUpdateListener { live.alpha = it.animatedValue as Float }
            start()
        }
        header(col, "Game Booster", "Telefoningiz o'yinga tayyormi?", live, true)

        // Gauge + BOOST
        val gc = card(14).apply { gravity = Gravity.CENTER_HORIZONTAL }
        gauge = GaugeView(this).apply { caption = "O'YIN TAYYORLIGI"; smallText = "Tekshirilmoqda" }
        gc.add(gauge, MATCH, WRAP)
        boostBtn = BoostButton(this)
        boostBtn.setOnClickListener {
            boostBtn.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
            runBoost()
        }
        gc.add(boostBtn, MATCH, dp(78), t = 2)
        resultText = tv("", 13f, C.GREEN, true).apply { gravity = Gravity.CENTER; visibility = View.GONE }
        gc.add(resultText, MATCH, WRAP, t = 6, b = 4)
        col.add(gc, b = 14)

        // 3 ta ko'rsatkich
        val (c1, v1, b1) = statCard("RAM BAND")
        val (c2, v2, b2) = statCard("HARORAT")
        val (c3, v3, b3) = statCard("BATAREYA")
        ramVal = v1; ramBar = b1; tempVal = v2; tempBar = b2; batVal = v3; batBar = b3
        val stats = hbox()
        stats.add(c1, 0, WRAP, r = 5, weight = 1f)
        stats.add(c2, 0, WRAP, l = 2, r = 2, weight = 1f)
        stats.add(c3, 0, WRAP, l = 5, weight = 1f)
        col.add(stats, b = 18)

        // Tezkor o'yin
        val gh = hbox()
        gh.add(sectionTitle("Tezkor o'yin"), 0, WRAP, weight = 1f)
        val all = tv("Hammasi ›", 13f, C.GREEN, true)
        all.setOnClickListener { select(1) }
        gh.add(all, WRAP, WRAP)
        col.add(gh, b = 10)
        val hs = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
        }
        homeRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        hs.addView(homeRow, ViewGroup.LayoutParams(WRAP, WRAP))
        col.add(hs, b = 18)

        // Mod menu
        val mc = card(16)
        val mrow = hbox()
        mrow.add(tv("🎛️", 28f), WRAP, WRAP, r = 14)
        val mt = vbox(0)
        mt.add(tv("Mod Menu paneli", 15f, C.TEXT, true), WRAP, WRAP)
        mt.add(tv("O'yin ustida suzib turadi: FPS, RAM, harorat, batareya, tarmoq", 12f, C.MUTED), WRAP, WRAP, t = 4)
        mrow.add(mt, 0, WRAP, r = 10, weight = 1f)
        overlayToggle = ToggleView(this)
        overlayToggle.onChange = { on ->
            if (on) {
                if (!startOverlay()) overlayToggle.toggleTo(false)
            } else {
                stopService(Intent(this, OverlayService::class.java))
            }
        }
        mrow.add(overlayToggle, WRAP, WRAP)
        mc.add(mrow)
        col.add(mc, b = 14)

        // Maslahatlar
        val tc = card(16)
        tc.add(sectionTitle("Maslahatlar"), b = 10)
        tipsBox = vbox(0)
        tc.add(tipsBox)
        col.add(tc)

        return sv to col
    }

    private fun refreshHome() {
        val m = Sys.mem(this)
        val b = Sys.batt(this)
        ramVal.text = "${m.usedPct.roundToInt()}%"
        ramBar.setPct(m.usedPct)
        ramBar.setColors(if (m.usedPct > 85) C.RED else if (m.usedPct > 70) C.ORANGE else C.GREEN, C.CYAN)

        tempVal.text = "${b.tempC}°C"
        tempBar.setPct((b.tempC - 20f) / 30f * 100f)
        tempBar.setColors(if (b.tempC >= 40) C.RED else if (b.tempC >= 37) C.ORANGE else C.GREEN, if (b.tempC >= 40) C.ORANGE else C.CYAN)

        batVal.text = "${b.level}%" + if (b.charging) " ⚡" else ""
        batBar.setPct(b.level.toFloat())
        batBar.setColors(if (b.level < 20) C.RED else if (b.level < 40) C.ORANGE else C.GREEN, C.CYAN)

        val r = Sys.readiness(this)
        gauge.setColors(r.c1, r.c2)
        gauge.smallText = r.label
        if (r.score != lastScore) {
            gauge.animateTo(r.score.toFloat(), if (lastScore < 0) 1500 else 900)
            lastScore = r.score
        }
        val key = r.tips.joinToString("|")
        if (key != lastTips) {
            lastTips = key
            tipsBox.removeAllViews()
            r.tips.forEachIndexed { i, s ->
                tipsBox.add(tv(s, 13f, C.TEXT).apply { setLineSpacing(0f, 1.15f) }, MATCH, WRAP, t = if (i == 0) 0 else 10)
            }
        }
    }

    private fun runBoost() {
        if (boosting) return
        boosting = true
        boostBtn.busy = true
        boostBtn.label = "TOZALANMOQDA…"
        gauge.scanning = true
        resultText.visibility = View.VISIBLE
        resultText.setTextColor(C.CYAN)
        resultText.text = "Fon ilovalar tekshirilmoqda…"
        val before = Booster.availMb(this)
        Thread {
            val n = Booster.kill(this, null)
            Thread.sleep(800)
            Booster.kill(this, null)
            Thread.sleep(900)
            val after = Booster.availMb(this)
            runOnUiThread { finishBoost(n, (after - before).coerceAtLeast(0)) }
        }.start()
    }

    private fun finishBoost(n: Int, freed: Long) {
        boosting = false
        boostBtn.busy = false
        boostBtn.label = "⚡  BOOST"
        gauge.scanning = false
        resultText.setTextColor(C.GREEN)
        countUp(resultText, freed.toInt(), "MB bo'shatildi ✅  ($n ta ilova)")
        val prefs = getSharedPreferences("nexus_history", MODE_PRIVATE)
        val old = prefs.getString("items", "") ?: ""
        val item = "${System.currentTimeMillis()}|$n|$freed"
        prefs.edit().putString("items", (item + if (old.isBlank()) "" else "\n$old").lines().take(12).joinToString("\n")).apply()
        refreshHome()
    }

    // ------------------------------------------------------------------ O'YINLAR

    private fun buildGames(): Pair<View, LinearLayout> {
        val (sv, col) = newPage()
        val add = ghostPill("➕  Qo'shish", C.GREEN)
        add.pressable { openPicker() }
        header(col, "O'yinlarim", "Game Library  •  Launch profiles", add, true)
        val premiumBanner = card(18).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.parseColor("#182B43"), Color.parseColor("#142B2A"))).apply {
                cornerRadius = dpf(20f); setStroke(dp(1), withAlpha(C.CYAN, 100))
            }
        }
        premiumBanner.add(tv("✦  NEXUS TURBO PREMIUM", 14f, C.CYAN, true), b = 6)
        premiumBanner.add(tv("Haqiqiy FPS imkoniyatlari, kengaytirilgan GAME BOOST, profillar va monitoring.", 12f, C.TEXT), b = 12)
        val premiumRow = hbox()
        val premiumAction = pill(if (premiumUnlocked) "✓ PREMIUM FAOL" else "PREMIUM OCHISH  ↗", C.CYAN, C.PURPLE, Color.WHITE, 12f)
        premiumAction.pressable { showPremium() }
        val promoAction = ghostPill("PROMOCODE", C.GREEN, 12f)
        promoAction.pressable { showPromoDialog() }
        premiumRow.add(premiumAction, 0, WRAP, r = 8, weight = 1f)
        premiumRow.add(promoAction, WRAP, WRAP)
        premiumBanner.add(premiumRow)
        col.add(premiumBanner, b = 14)
        gamesGrid = vbox(0)
        col.add(gamesGrid)
        return sv to col
    }

    private fun openPicker() = GamePicker(this) { renderGames() }.show()

    private fun homeGameItem(pkg: String): View {
        val c = vbox(dp(10)).apply {
            gravity = Gravity.CENTER_HORIZONTAL
            background = cardBg(18f)
        }
        val ic = ImageView(this).apply {
            setImageDrawable(Booster.icon(this@MainActivity, pkg))
            roundClip(14f)
        }
        c.add(ic, dp(54), dp(54))
        c.add(
            tv(Booster.label(this, pkg), 11f, C.TEXT, true).apply {
                gravity = Gravity.CENTER; maxLines = 1; ellipsize = TextUtils.TruncateAt.END
            }, MATCH, WRAP, t = 8
        )
        c.pressable { launch(pkg) }
        return c
    }

    private fun addItem(): View {
        val c = vbox(dp(10)).apply {
            gravity = Gravity.CENTER
            background = roundedBg(Color.TRANSPARENT, 18f, withAlpha(C.GREEN, 120), 1)
        }
        c.add(tv("＋", 26f, C.GREEN, true).apply { gravity = Gravity.CENTER }, MATCH, dp(54))
        c.add(tv("Qo'shish", 11f, C.GREEN, true).apply { gravity = Gravity.CENTER }, MATCH, WRAP, t = 8)
        c.pressable { openPicker() }
        return c
    }

    private fun gameCard(pkg: String): View {
        val c = card(14).apply { gravity = Gravity.CENTER_HORIZONTAL }
        val ic = ImageView(this).apply {
            setImageDrawable(Booster.icon(this@MainActivity, pkg))
            roundClip(18f)
        }
        c.add(ic, dp(68), dp(68))
        c.add(
            tv(Booster.label(this, pkg), 13f, C.TEXT, true).apply {
                gravity = Gravity.CENTER; maxLines = 1; ellipsize = TextUtils.TruncateAt.END
            }, MATCH, WRAP, t = 10
        )
        val boost = pill("⚡  GAME BOOST", C.CYAN, C.PURPLE, Color.WHITE, 12f)
        boost.pressable { showGameBoost(pkg) }
        c.add(boost, MATCH, WRAP, t = 10)
        val play = ghostPill("▶  O'ynash", C.GREEN, 12f)
        play.pressable { launch(pkg) }
        c.add(play, MATCH, WRAP, t = 7)
        c.setOnLongClickListener {
            confirmRemove(pkg)
            true
        }
        return c
    }

    // ---------------------- Nexus Turbo Premium + GAME BOOST ----------------------

    private fun premiumTile(title: String, subtitle: String, value: String, locked: Boolean): View {
        val c = card(14)
        val r = hbox()
        val t = vbox(0)
        t.add(tv(title, 13f, C.TEXT, true), WRAP, WRAP)
        t.add(tv(subtitle, 11f, C.MUTED), WRAP, WRAP, t = 3)
        r.add(t, 0, WRAP, r = 8, weight = 1f)
        r.add(tv(if (locked) "🔒" else value, 14f, if (locked) C.CYAN else C.GREEN, true), WRAP, WRAP)
        c.add(r)
        c.pressable {
            when {
                locked -> showPremium()
                title.contains("FPS (Nexus") -> runUiFpsTest()
                title.contains("Game FPS") -> AlertDialog.Builder(this).setTitle("Game FPS")
                    .setMessage("O'yinning render FPS'ini Android ilovalari odatda bevosita o'qiy olmaydi. Premium UI ochiladi, lekin haqiqiy FPS ko'rsatkichi qurilma qo'llab-quvvatlashi, Android Game Dashboard yoki maxsus ruxsat (Shizuku/root) talab qilishi mumkin. Soxta raqam ko'rsatmaymiz.")
                    .setPositiveButton("Tushunarli", null).show()
            }
        }
        return c
    }

    private fun showGameBoost(pkg: String) {
        val d = Dialog(this)
        val root = vbox(dp(16)).apply {
            background = roundedBg(C.BG, 24f, withAlpha(C.CYAN, 120), 1)
            setPadding(dp(18), dp(18), dp(18), dp(18))
        }
        val header = hbox()
        val icon = ImageView(this).apply { setImageDrawable(Booster.icon(this@MainActivity, pkg)); roundClip(16f) }
        header.add(icon, dp(56), dp(56), r = 12)
        val titleCol = vbox(0)
        titleCol.add(tv("GAME BOOST", 18f, C.CYAN, true), WRAP, WRAP)
        titleCol.add(tv(Booster.label(this, pkg), 13f, C.TEXT, true), WRAP, WRAP, t = 4)
        titleCol.add(tv("Maxsus o'yin profili", 11f, C.MUTED), WRAP, WRAP, t = 3)
        header.add(titleCol, 0, WRAP, weight = 1f)
        root.add(header, b = 14)
        val scan = card(16)
        scan.add(tv("⚡  SMART PRE-GAME SCAN", 13f, C.GREEN, true), b = 8)
        scan.add(tv("RAM • Batareya • Harorat • Tarmoq • Overlay", 11f, C.MUTED), b = 10)
        val stats = hbox()
        val mem = Sys.mem(this); val batt = Sys.batt(this)
        stats.add(metricMini("RAM", "${mem.usedPct.roundToInt()}%"), 0, WRAP, r = 5, weight = 1f)
        stats.add(metricMini("TEMP", "${batt.tempC}°C"), 0, WRAP, l = 3, r = 3, weight = 1f)
        stats.add(metricMini("BATTERY", "${batt.level}%"), 0, WRAP, l = 5, weight = 1f)
        scan.add(stats)
        root.add(scan, b = 12)
        root.add(tv("BOOST TUNING", 12f, C.CYAN, true), b = 8)
        root.add(premiumTile("Balanced Profile", "Barqaror ishlash va kamroq qizish", "READY", false), b = 6)
        root.add(premiumTile("Performance Profile", "O'yin oldidan monitoring va fon ilovalarini tekshiradi", "READY", false), b = 6)
        root.add(premiumTile("Extreme Profile", "Qo'shimcha monitoring va HUD sozlamalari", "PREMIUM", !premiumUnlocked), b = 6)
        root.add(premiumTile("Game FPS (haqiqiy)", "O'yin render FPS'i — qurilma/Android qo'llab-quvvatlashi talab qilinadi", "LOCKED", !premiumUnlocked), b = 6)
        root.add(premiumTile("FPS (Nexus UI)", "Ilova oynasi frame rate testi — o'yin FPS'i emas", "TEST", false), b = 6)
        val buttons = hbox()
        val launch = pill("⚡ BOOST & OCHISH", C.GREEN, C.CYAN, C.DARK_TEXT, 13f)
        launch.pressable { d.dismiss(); launch(pkg) }
        val close = ghostPill("Yopish", C.MUTED, 12f)
        close.pressable { d.dismiss() }
        buttons.add(launch, 0, WRAP, r = 8, weight = 1f)
        buttons.add(close, WRAP, WRAP)
        root.add(buttons, t = 10)
        d.setContentView(root)
        d.window?.setBackgroundDrawableResource(android.R.color.transparent)
        d.window?.setLayout((resources.displayMetrics.widthPixels * .92f).toInt(), WRAP)
        d.show()
        d.window?.setLayout((resources.displayMetrics.widthPixels * .92f).toInt(), WRAP)
    }

    private fun metricMini(title: String, value: String): View = vbox(dp(6)).apply {
        gravity = Gravity.CENTER
        background = roundedBg(C.SURFACE2, 12f, C.STROKE, 1)
        add(tv(title, 9f, C.MUTED, true), MATCH, WRAP)
        add(tv(value, 15f, C.TEXT, true), MATCH, WRAP, t = 4)
    }

    private fun showPremium() {
        if (premiumUnlocked) {
            AlertDialog.Builder(this).setTitle("Nexus Turbo Premium ✓")
                .setMessage("Premium ushbu qurilmada faol. Barcha Premium panellar ochilgan.")
                .setPositiveButton("OK", null).show()
            return
        }
        AlertDialog.Builder(this).setTitle("✦ Nexus Turbo Premium")
            .setMessage("Premium imkoniyatlar:\n\n• GAME BOOST kengaytirilgan profillari\n• Premium HUD va monitoring kartalari\n• FPS bo'limi (Android/device qo'llab-quvvatlasa)\n• Performance History\n• Qo'shimcha test va sozlamalar\n\nPromocode orqali sovg'a Premiumni ochishingiz mumkin.")
            .setPositiveButton("Promocode kiritish") { _, _ -> showPromoDialog() }
            .setNegativeButton("Keyin", null).show()
    }

    private fun showPromoDialog() {
        val input = android.widget.EditText(this).apply {
            hint = "Promocode"
            setTextColor(C.TEXT); setHintTextColor(C.MUTED)
            isSingleLine = true
            background = roundedBg(C.SURFACE2, 14f, C.STROKE, 1)
            setPadding(dp(14), dp(12), dp(14), dp(12))
        }
        val wrap = vbox(dp(10)).apply { setPadding(dp(18), dp(8), dp(18), 0) }
        wrap.add(input, MATCH, WRAP)
        wrap.add(tv("Sovg'a: Lifetime Premium. Kod qurilmada bir marta ishlaydi. Global birinchi 5 foydalanuvchini cheklash server talab qiladi.", 11f, C.MUTED), MATCH, WRAP, t = 6)
        AlertDialog.Builder(this).setTitle("🎁 Promocode")
            .setView(wrap)
            .setPositiveButton("Faollashtirish") { _, _ ->
                val code = input.text.toString().trim()
                val promoPrefs = getSharedPreferences("nexus_premium", MODE_PRIVATE)
                if (code == "NexusTurboHappyBirthday" && !promoPrefs.getBoolean("promo_redeemed", false)) {
                    promoPrefs.edit().putBoolean("premium", true).putBoolean("promo_redeemed", true).apply()
                    premiumUnlocked = true
                    toast("Lifetime Premium faollashtirildi! 🎉")
                    renderGames()
                } else if (code == "NexusTurboHappyBirthday" && promoPrefs.getBoolean("promo_redeemed", false)) {
                    toast("Promocode ushbu qurilmada allaqachon ishlatilgan")
                } else toast("Promocode noto'g'ri")
            }
            .setNegativeButton("Bekor", null).show()
    }

    private fun runUiFpsTest() {
        val dialog = AlertDialog.Builder(this).setTitle("Nexus UI FPS Test")
            .setMessage("5 soniya davomida ilova oynasi frame callback'larini o'lchaydi. Bu o'yinning haqiqiy FPS'i emas.")
            .setPositiveButton("Boshlash", null).setNegativeButton("Yopish", null).create()
        dialog.show()
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            dialog.setMessage("O'lchanmoqda…")
            val start = android.os.SystemClock.elapsedRealtime()
            var frames = 0
            val cb = object : android.view.Choreographer.FrameCallback {
                override fun doFrame(time: Long) {
                    frames++
                    if (android.os.SystemClock.elapsedRealtime() - start < 5000) {
                        android.view.Choreographer.getInstance().postFrameCallback(this)
                    } else {
                        val elapsed = (android.os.SystemClock.elapsedRealtime() - start).coerceAtLeast(1)
                        val fps = (frames * 1000f / elapsed).roundToInt()
                        dialog.setMessage("Natija: $fps FPS\n\nBu Nexus Turbo ekrani frame rate'i. O'yin FPS'i emas.")
                        dialog.getButton(AlertDialog.BUTTON_POSITIVE).text = "Qayta test"
                    }
                }
            }
            frames = 0
            android.view.Choreographer.getInstance().postFrameCallback(cb)
        }
    }

    private fun confirmRemove(pkg: String) {
        AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle(Booster.label(this, pkg))
            .setMessage("Ro'yxatdan olib tashlansinmi?")
            .setPositiveButton("Olib tashlash") { _, _ ->
                val s = Booster.games(this).toMutableSet()
                s.remove(pkg)
                Booster.saveGames(this, s)
                renderGames()
            }
            .setNegativeButton("Bekor", null)
            .show()
    }

    private fun renderGames() {
        val games = Booster.games(this).sortedBy { Booster.label(this, it).lowercase() }

        homeRow.removeAllViews()
        for (p in games) homeRow.add(homeGameItem(p), dp(88), WRAP, r = 10)
        homeRow.add(addItem(), dp(88), MATCH)

        gamesGrid.removeAllViews()
        if (games.isEmpty()) {
            val e = card(24).apply { gravity = Gravity.CENTER_HORIZONTAL }
            e.add(tv("🎮", 44f).apply { gravity = Gravity.CENTER }, MATCH, WRAP)
            e.add(tv("Hali o'yin qo'shilmagan", 17f, C.TEXT, true).apply { gravity = Gravity.CENTER }, MATCH, WRAP, t = 10)
            e.add(
                tv("Telefoningizdagi o'yinlarni ikonkalari bilan tanlang", 13f, C.MUTED).apply { gravity = Gravity.CENTER },
                MATCH, WRAP, t = 6, b = 16
            )
            val b = pill("➕  O'yin qo'shish", C.GREEN, C.CYAN, C.DARK_TEXT, 15f)
            b.pressable { openPicker() }
            e.add(b, MATCH, WRAP)
            gamesGrid.add(e)
        } else {
            games.chunked(2).forEach { pair ->
                val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                pair.forEachIndexed { i, p ->
                    row.add(gameCard(p), 0, WRAP, r = if (i == 0) 6 else 0, l = if (i == 1) 6 else 0, weight = 1f)
                }
                if (pair.size == 1) row.add(View(this), 0, 1, l = 6, weight = 1f)
                gamesGrid.add(row, b = 12)
            }
            gamesGrid.add(
                tv("💡 O'yinni olib tashlash uchun kartani bosib turing", 12f, C.MUTED).apply { gravity = Gravity.CENTER },
                MATCH, WRAP, t = 4
            )
        }
        if (current == 1) staggerIn(gamesGrid)
    }

    private fun launch(pkg: String) {
        val i = packageManager.getLaunchIntentForPackage(pkg)
        if (i == null) {
            toast("O'yin topilmadi")
            return
        }
        if (Booster.flag(this, "auto_dnd", false)) Booster.setDnd(this, true)
        Booster.kill(this, pkg)
        if (Booster.flag(this, "auto_overlay", true) && Settings.canDrawOverlays(this)) {
            try {
                startForegroundService(Intent(this, OverlayService::class.java))
            } catch (e: Throwable) {
            }
        }
        startActivity(i)
    }

    private fun startOverlay(): Boolean {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Avval \"Boshqa ilovalar ustida ko'rsatish\" ruxsatini bering", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return false
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 11)
        }
        startForegroundService(Intent(this, OverlayService::class.java))
        return true
    }

    // ------------------------------------------------------------------ QURILMA

    private fun buildDevice(): Pair<View, LinearLayout> {
        val (sv, col) = newPage()
        val copy = ghostPill("📋 Nusxalash")
        copy.pressable {
            if (deviceText.isEmpty()) return@pressable
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("Qurilma", deviceText))
            toast("Nusxalandi ✅")
        }
        header(col, "Qurilma", "Telefon haqida to'liq ma'lumot", copy)
        deviceLoading = tv("Ma'lumotlar yig'ilmoqda…", 14f, C.MUTED).apply { gravity = Gravity.CENTER }
        col.add(deviceLoading, MATCH, WRAP, t = 30)
        return sv to col
    }

    private fun loadDeviceInfo() {
        Thread {
            val sections = Sys.deviceSections(this)
            runOnUiThread { fillDevice(sections) }
        }.start()
    }

    private fun infoCard(title: String, rows: List<Pair<String, String>>): View {
        val c = card(16)
        c.add(tv(title, 15f, C.TEXT, true), b = 10)
        rows.forEachIndexed { i, (k, v) ->
            if (i > 0) c.add(View(this).apply { setBackgroundColor(Color.parseColor("#14FFFFFF")) }, MATCH, 1)
            val r = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(0, dp(9), 0, dp(9))
            }
            r.add(tv(k, 13f, C.MUTED), WRAP, WRAP)
            r.add(tv(v, 13f, C.TEXT, true).apply { gravity = Gravity.END }, 0, WRAP, l = 16, weight = 1f)
            c.add(r)
        }
        return c
    }

    private fun fillDevice(sections: InfoSections) {
        val col = pageContents[2]
        col.removeView(deviceLoading)

        val m = Sys.mem(this)
        val (stTotal, _) = Sys.storage()
        val hero = vbox(dp(18)).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.parseColor("#123A4F"), Color.parseColor("#13241F"))
            ).apply {
                cornerRadius = dpf(22f)
                setStroke(dp(1), withAlpha(C.GREEN, 90))
            }
        }
        hero.add(tv(Build.MANUFACTURER.uppercase(), 11f, C.GREEN, true).apply { letterSpacing = 0.18f })
        hero.add(tv(Build.MODEL, 24f, C.TEXT, true), MATCH, WRAP, t = 6)
        val chips = hbox()
        chips.add(chip("Android ${Build.VERSION.RELEASE}", C.CYAN), WRAP, WRAP, r = 8)
        chips.add(chip("RAM ${Sys.fmtMb(m.totalMb)}", C.GREEN), WRAP, WRAP, r = 8)
        chips.add(chip(Sys.fmtBytes(stTotal), C.PURPLE), WRAP, WRAP)
        hero.add(chips, MATCH, WRAP, t = 14)
        col.add(hero, b = 12)

        val sb = StringBuilder()
        sb.append("${Build.MANUFACTURER} ${Build.MODEL}\n")
        for ((title, rows) in sections) {
            col.add(infoCard(title, rows), b = 12)
            sb.append("\n$title\n")
            rows.forEach { sb.append("  ${it.first}: ${it.second.replace("\n", ", ")}\n") }
        }
        deviceText = sb.toString()
        if (current == 2) staggerIn(col)
    }

    // ------------------------------------------------------------------ ASBOBLAR

    private fun toggleRow(title: String, desc: String, key: String, def: Boolean): View {
        val r = hbox().apply { setPadding(0, dp(8), 0, dp(8)) }
        val t = vbox(0)
        t.add(tv(title, 14f, C.TEXT, true), WRAP, WRAP)
        t.add(tv(desc, 12f, C.MUTED), WRAP, WRAP, t = 3)
        r.add(t, 0, WRAP, r = 10, weight = 1f)
        val tg = ToggleView(this)
        tg.toggleTo(Booster.flag(this, key, def), false)
        tg.onChange = { on ->
            Booster.setFlag(this, key, on)
            if (key == "auto_dnd" && on && !Booster.dndGranted(this)) {
                toast("DND uchun ruxsat bering")
                startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
            }
        }
        r.add(tg, WRAP, WRAP)
        return r
    }

    private fun permRow(title: String, desc: String, granted: () -> Boolean, request: () -> Unit): View {
        val r = hbox().apply { setPadding(0, dp(8), 0, dp(8)) }
        val t = vbox(0)
        t.add(tv(title, 14f, C.TEXT, true), WRAP, WRAP)
        t.add(tv(desc, 12f, C.MUTED), WRAP, WRAP, t = 3)
        r.add(t, 0, WRAP, r = 10, weight = 1f)
        val b = ghostPill("Berish", C.TEXT, 12f)
        b.pressable { if (!granted()) request() }
        permUpdaters.add {
            if (granted()) {
                b.text = "✓ Berilgan"; b.setTextColor(C.GREEN)
                b.background = roundedBg(withAlpha(C.GREEN, 30), 22f, withAlpha(C.GREEN, 90), 1)
            } else {
                b.text = "Berish"; b.setTextColor(C.TEXT)
                b.background = roundedBg(C.SURFACE2, 22f, C.STROKE, 1)
            }
        }
        r.add(b, WRAP, WRAP)
        return r
    }

    private fun quickTile(emoji: String, title: String, action: String): View {
        val t = card(14).apply { gravity = Gravity.CENTER_HORIZONTAL }
        t.add(tv(emoji, 26f).apply { gravity = Gravity.CENTER }, MATCH, WRAP)
        t.add(tv(title, 12f, C.TEXT, true).apply { gravity = Gravity.CENTER }, MATCH, WRAP, t = 8)
        t.pressable {
            try {
                startActivity(Intent(action))
            } catch (e: Throwable) {
                toast("Bu sozlama ochilmadi")
            }
        }
        return t
    }

    private fun buildTools(): Pair<View, LinearLayout> {
        val (sv, col) = newPage()
        header(col, "Asboblar", "Sozlamalar va o'yin uchun foydali vositalar")

        // Ping
        val pc = card(16)
        pc.add(tv("📡  Ping testi", 16f, C.TEXT, true))
        pc.add(tv("Online o'yin uchun server javob vaqti", 12f, C.MUTED), WRAP, WRAP, t = 4, b = 12)
        pingTargets.forEachIndexed { i, tg ->
            val r = hbox().apply { setPadding(0, dp(8), 0, dp(8)) }
            r.add(tv(tg.first, 14f, C.TEXT, true), 0, WRAP, weight = 1f)
            val q = tv("", 11f, C.MUTED, true)
            val v = tv("—", 15f, C.MUTED, true)
            r.add(q, WRAP, WRAP, r = 12)
            r.add(v, dp(64), WRAP)
            v.gravity = Gravity.END
            pingViews.add(Pair(v, q))
            if (i > 0) pc.add(View(this).apply { setBackgroundColor(Color.parseColor("#14FFFFFF")) }, MATCH, 1)
            pc.add(r)
        }
        pingBtn = pill("Ping o'lchash", C.CYAN, C.PURPLE, Color.WHITE, 14f)
        pingBtn.pressable { runPing() }
        pc.add(pingBtn, MATCH, WRAP, t = 12)
        col.add(pc, b = 14)

        // Avtomatik
        val ac = card(16)
        ac.add(tv("⚙️  Avtomatik rejim", 16f, C.TEXT, true), b = 6)
        ac.add(toggleRow("Mod Menu o'yin bilan ochilsin", "O'yin ishga tushganda panel avtomatik chiqadi", "auto_overlay", true))
        ac.add(toggleRow("O'yinda DND yoqilsin", "Bildirishnoma va qo'ng'iroqlar halaqit bermaydi", "auto_dnd", false))
        val dr = hbox().apply { setPadding(0, dp(8), 0, dp(8)) }
        val dt = vbox(0)
        dt.add(tv("Bezovta qilmang (hozir)", 14f, C.TEXT, true), WRAP, WRAP)
        dt.add(tv("Darhol yoqish yoki o'chirish", 12f, C.MUTED), WRAP, WRAP, t = 3)
        dr.add(dt, 0, WRAP, r = 10, weight = 1f)
        dndToggle = ToggleView(this)
        dndToggle.onChange = { on ->
            if (!Booster.setDnd(this, on)) {
                dndToggle.toggleTo(false)
                toast("DND uchun ruxsat bering")
                startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
            }
        }
        dr.add(dndToggle, WRAP, WRAP)
        ac.add(dr)
        col.add(ac, b = 14)

        // Ruxsatlar
        val rc = card(16)
        rc.add(tv("🔐  Ruxsatlar", 16f, C.TEXT, true), b = 6)
        rc.add(permRow("Boshqa ilovalar ustida", "Mod Menu paneli uchun", { Settings.canDrawOverlays(this) }) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        rc.add(permRow("Bezovta qilmang rejimi", "DND ni boshqarish uchun", { Booster.dndGranted(this) }) {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
        })
        rc.add(permRow("Bildirishnomalar", "Panel ishlayotganini ko'rsatadi", {
            Build.VERSION.SDK_INT < 33 || checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        }) {
            if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 11)
        })
        col.add(rc, b = 14)

        // Tezkor sozlamalar
        col.add(sectionTitle("Tezkor sozlamalar"), b = 10)
        val q1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        q1.add(quickTile("🖥️", "Ekran (Hz)", Settings.ACTION_DISPLAY_SETTINGS), 0, WRAP, r = 6, weight = 1f)
        q1.add(quickTile("🔋", "Batareya", Settings.ACTION_BATTERY_SAVER_SETTINGS), 0, WRAP, l = 6, weight = 1f)
        col.add(q1, b = 12)
        val q2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        q2.add(quickTile("🛠️", "Dasturchi", Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS), 0, WRAP, r = 6, weight = 1f)
        q2.add(quickTile("📶", "Tarmoq", Settings.ACTION_WIRELESS_SETTINGS), 0, WRAP, l = 6, weight = 1f)
        col.add(q2, b = 14)

        // Nexus Turbo qo'shimcha vositalari
        col.add(sectionTitle("Nexus Turbo Lab"), b = 10)
        val lab = card(16)
        lab.add(tv("🧪  Performance & Utility Lab", 15f, C.CYAN, true), b = 6)
        lab.add(tv("Cache bo'yicha yordam, touch test, storage tahlili va performance profillari.", 12f, C.MUTED), b = 12)
        val cache = ghostPill("CACHE YORDAMI", C.GREEN, 12f)
        cache.pressable { showCacheHelper() }
        val touch = ghostPill("TOUCH TEST", C.CYAN, 12f)
        touch.pressable { showTouchTest() }
        val prof = ghostPill("PROFILES", C.PURPLE, 12f)
        prof.pressable { showProfiles() }
        lab.add(cache, MATCH, WRAP, b = 8)
        lab.add(touch, MATCH, WRAP, b = 8)
        val storage = ghostPill("STORAGE ANALYZER", C.CYAN, 12f)
        storage.pressable { showStorageInfo() }
        val history = ghostPill("BOOST HISTORY", C.GREEN, 12f)
        history.pressable { showBoostHistory() }
        lab.add(prof, MATCH, WRAP, b = 8)
        lab.add(storage, MATCH, WRAP, b = 8)
        lab.add(history, MATCH, WRAP)
        col.add(lab, b = 14)

        // Haqida
        val ab = card(16)
        ab.add(tv("ℹ️  Haqida", 16f, C.TEXT, true), b = 8)
        ab.add(
            tv(
                "Game Booster 2.0\n\n" +
                    "• BOOST fon ilovalarni to'xtatadi. Tizim ba'zi jarayonlarni qayta ishga tushirishi mumkin, bu normal.\n" +
                    "• Mod Menu'dagi FPS ekran yangilanishini (tizim yukini) o'lchaydi. O'yinning ichki FPS'ini oddiy ilova o'qiy olmaydi, buning uchun root yoki Shizuku kerak.\n" +
                    "• CPU/GPU chastotasini rootsiz oshirib bo'lmaydi.",
                12f, C.MUTED
            ).apply { setLineSpacing(0f, 1.2f) }
        )
        col.add(ab)

        return sv to col
    }

    private fun showCacheHelper() {
        val games = Booster.games(this).toList()
        if (games.isEmpty()) {
            AlertDialog.Builder(this).setTitle("Cache yordam")
                .setMessage("Avval O'yinlar bo'limidan o'yin qo'shing. Cache tozalash Android sozlamalarida bajariladi; Clear cache ni tanlang, Clear data emas.")
                .setPositiveButton("Ilova sozlamalari") { _, _ -> startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))) }
                .setNegativeButton("Yopish", null).show()
            return
        }
        val labels = games.map { Booster.label(this, it) }.toTypedArray()
        AlertDialog.Builder(this).setTitle("Cache tozalashga yordam")
            .setItems(labels) { _, which ->
                val pkg = games[which]
                AlertDialog.Builder(this).setTitle(labels[which])
                    .setMessage("App Info ochiladi. Storage → Clear cache ni tanlang. Clear data/Storage tugmasini bosmang, u o'yin ma'lumotlarini o'chirishi mumkin.")
                    .setPositiveButton("App Info ochish") { _, _ ->
                        try { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg"))) }
                        catch (_: Throwable) { toast("App Info ochilmadi") }
                    }.setNegativeButton("Bekor", null).show()
            }.setNegativeButton("Yopish", null).show()
    }

    private fun showStorageInfo() {
        val (total, free) = Sys.storage()
        val used = (total - free).coerceAtLeast(0)
        AlertDialog.Builder(this).setTitle("Storage Analyzer")
            .setMessage("Internal storage\n\nUsed: ${Sys.fmtBytes(used)}\nFree: ${Sys.fmtBytes(free)}\nTotal: ${Sys.fmtBytes(total)}\n\nAndroid ilovalar cache'larini boshqa ilovadan avtomatik o'chirishni cheklaydi. Cache tozalash bo'yicha yo'riqnomadan foydalaning.")
            .setPositiveButton("Cache yordam", null).setNegativeButton("Yopish", null).show()
    }

    private fun showBoostHistory() {
        val records = getSharedPreferences("nexus_history", MODE_PRIVATE).getString("items", "") ?: ""
        val lines = records.lines().filter { it.isNotBlank() }.mapNotNull { row ->
            val p = row.split("|")
            if (p.size < 3) null else try {
                val date = java.text.SimpleDateFormat("dd.MM  HH:mm", java.util.Locale.getDefault()).format(java.util.Date(p[0].toLong()))
                "$date  •  ${p[1]} app  •  ${p[2]} MB"
            } catch (_: Throwable) { null }
        }
        AlertDialog.Builder(this).setTitle("Performance History")
            .setMessage(if (lines.isEmpty()) "Hali BOOST tarixi yo'q. BOOST ishga tushirgandan keyin natijalar saqlanadi." else lines.joinToString("\n"))
            .setPositiveButton("OK", null).show()
    }

    private fun showProfiles() {
        val profiles = arrayOf("Balanced — barqaror, odatiy sarf", "Performance — o'yin oldidan Boost va monitoring", "Battery Saver — energiyani tejash")
        AlertDialog.Builder(this).setTitle("Gaming Profiles")
            .setItems(profiles) { _, which ->
                when (which) {
                    0 -> {
                        Booster.setFlag(this, "auto_overlay", false)
                        Booster.setFlag(this, "auto_dnd", false)
                        toast("Balanced profil: standart rejim")
                    }
                    1 -> {
                        Booster.setFlag(this, "auto_overlay", true)
                        Booster.setFlag(this, "auto_dnd", true)
                        if (!Booster.dndGranted(this)) startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
                        runBoost(); toast("Performance profil: Boost + overlay + DND")
                    }
                    2 -> {
                        Booster.setFlag(this, "auto_overlay", false)
                        Booster.setFlag(this, "auto_dnd", false)
                        try { startActivity(Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS)) } catch (_: Throwable) { toast("Battery Saver sozlamasi topilmadi") }
                    }
                }
            }.setNegativeButton("Yopish", null).show()
    }

    private fun showTouchTest() {
        val d = Dialog(this)
        val root = FrameLayout(this).apply { background = roundedBg(C.BG, 20f, C.CYAN, 1) }
        val text = tv("TOUCH TEST\n\nEkranga bosing yoki suring\nTouchlar: 0", 20f, C.TEXT, true).apply { gravity = Gravity.CENTER }
        root.addView(text, FrameLayout.LayoutParams(MATCH, MATCH))
        var count = 0
        root.setOnTouchListener { _, event ->
            if (event.action == android.view.MotionEvent.ACTION_DOWN || event.action == android.view.MotionEvent.ACTION_MOVE) {
                count++
                text.text = "TOUCH TEST\n\nKoordinata: ${event.x.roundToInt()}, ${event.y.roundToInt()}\nTouch event: $count\nFinger: ${event.pointerCount}"
            }
            true
        }
        d.setContentView(root)
        d.window?.setBackgroundDrawableResource(android.R.color.transparent)
        d.window?.setLayout((resources.displayMetrics.widthPixels * .9f).toInt(), dp(380))
        d.show(); d.window?.setLayout((resources.displayMetrics.widthPixels * .9f).toInt(), dp(380))
    }

    private fun runPing() {
        if (pinging) return
        pinging = true
        pingBtn.text = "O'lchanmoqda…"
        pingViews.forEach {
            it.first.text = "…"; it.first.setTextColor(C.MUTED); it.second.text = ""
        }
        Thread {
            pingTargets.forEachIndexed { i, t ->
                val samples = (1..3).map { Sys.ping(t.second) }.filter { it >= 0 }
                val ms = if (samples.isEmpty()) -1L else samples.sum() / samples.size
                runOnUiThread { showPing(i, ms) }
            }
            runOnUiThread {
                pinging = false
                pingBtn.text = "Qayta o'lchash"
            }
        }.start()
    }

    private fun showPing(i: Int, ms: Long) {
        val (v, q) = pingViews[i]
        val (txt, label, col) = when {
            ms < 0 -> Triple("Xato", "ULANMADI", C.RED)
            ms < 50 -> Triple("$ms ms", "A'LO", C.GREEN)
            ms < 100 -> Triple("$ms ms", "YAXSHI", C.GREEN)
            ms < 200 -> Triple("$ms ms", "O'RTACHA", C.ORANGE)
            else -> Triple("$ms ms", "YOMON", C.RED)
        }
        v.text = txt
        v.setTextColor(col)
        q.text = label
        q.setTextColor(col)
        v.alpha = 0f
        v.animate().alpha(1f).setDuration(300).start()
    }
}
