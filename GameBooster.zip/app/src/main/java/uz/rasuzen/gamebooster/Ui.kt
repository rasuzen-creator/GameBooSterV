package uz.rasuzen.gamebooster

import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.animation.DecelerateInterpolator
import android.widget.LinearLayout
import android.widget.TextView

const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

object C {
    val BG = Color.parseColor("#0B0E14")
    val SURFACE = Color.parseColor("#141923")
    val SURFACE2 = Color.parseColor("#1B2230")
    val STROKE = Color.parseColor("#26FFFFFF")
    val GREEN = Color.parseColor("#22E58A")
    val CYAN = Color.parseColor("#00D1FF")
    val PURPLE = Color.parseColor("#8B5CF6")
    val ORANGE = Color.parseColor("#FFB020")
    val YELLOW = Color.parseColor("#FFD166")
    val RED = Color.parseColor("#FF4D6A")
    val TEXT = Color.parseColor("#F2F5FA")
    val MUTED = Color.parseColor("#8A94A6")
    val DARK_TEXT = Color.parseColor("#06130C")
}

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()
fun Context.dpf(v: Float): Float = v * resources.displayMetrics.density
fun View.dp(v: Int): Int = context.dp(v)
fun View.dpf(v: Float): Float = context.dpf(v)

fun withAlpha(color: Int, a: Int): Int = (color and 0x00FFFFFF) or (a shl 24)

fun Context.roundedBg(color: Int, radiusDp: Float, strokeColor: Int = 0, strokeDp: Int = 0): GradientDrawable =
    GradientDrawable().apply {
        setColor(color)
        cornerRadius = dpf(radiusDp)
        if (strokeDp > 0) setStroke(dp(strokeDp), strokeColor)
    }

fun Context.gradBg(
    c1: Int, c2: Int, radiusDp: Float,
    o: GradientDrawable.Orientation = GradientDrawable.Orientation.LEFT_RIGHT
): GradientDrawable = GradientDrawable(o, intArrayOf(c1, c2)).apply { cornerRadius = dpf(radiusDp) }

fun Context.cardBg(radiusDp: Float = 20f): GradientDrawable =
    GradientDrawable(
        GradientDrawable.Orientation.TL_BR,
        intArrayOf(Color.parseColor("#1A2233"), Color.parseColor("#121722"))
    ).apply {
        cornerRadius = dpf(radiusDp)
        setStroke(dp(1), C.STROKE)
    }

fun Context.tv(text: String, sizeSp: Float = 14f, color: Int = C.TEXT, bold: Boolean = false): TextView =
    TextView(this).apply {
        this.text = text
        textSize = sizeSp
        setTextColor(color)
        typeface = if (bold) Typeface.create("sans-serif-medium", Typeface.BOLD) else Typeface.create("sans-serif", Typeface.NORMAL)
        includeFontPadding = false
    }

fun Context.vbox(pad: Int = 0): LinearLayout = LinearLayout(this).apply {
    orientation = LinearLayout.VERTICAL
    setPadding(pad, pad, pad, pad)
}

fun Context.hbox(): LinearLayout = LinearLayout(this).apply {
    orientation = LinearLayout.HORIZONTAL
    gravity = Gravity.CENTER_VERTICAL
}

fun Context.card(padDp: Int = 16): LinearLayout = vbox(dp(padDp)).apply { background = cardBg() }

fun Context.chip(text: String, color: Int): TextView = tv(text, 11f, color, true).apply {
    background = roundedBg(withAlpha(color, 38), 12f)
    setPadding(dp(10), dp(5), dp(10), dp(5))
}

fun Context.pill(text: String, c1: Int = C.GREEN, c2: Int = C.CYAN, textColor: Int = C.DARK_TEXT, sizeSp: Float = 14f): TextView =
    tv(text, sizeSp, textColor, true).apply {
        gravity = Gravity.CENTER
        background = gradBg(c1, c2, 22f)
        setPadding(dp(18), dp(11), dp(18), dp(11))
    }

fun Context.ghostPill(text: String, color: Int = C.TEXT, sizeSp: Float = 13f): TextView =
    tv(text, sizeSp, color, true).apply {
        gravity = Gravity.CENTER
        background = roundedBg(C.SURFACE2, 22f, C.STROKE, 1)
        setPadding(dp(16), dp(10), dp(16), dp(10))
    }

fun LinearLayout.add(
    v: View, w: Int = MATCH, h: Int = WRAP,
    l: Int = 0, t: Int = 0, r: Int = 0, b: Int = 0, weight: Float = 0f
): View {
    val p = LinearLayout.LayoutParams(w, h, weight)
    p.setMargins(context.dp(l), context.dp(t), context.dp(r), context.dp(b))
    addView(v, p)
    return v
}

@SuppressLint("ClickableViewAccessibility")
fun View.pressable(onClick: () -> Unit) {
    isClickable = true
    setOnTouchListener { v, e ->
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> v.animate().scaleX(0.95f).scaleY(0.95f).setDuration(90).start()
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> v.animate().scaleX(1f).scaleY(1f).setDuration(160).start()
        }
        false
    }
    setOnClickListener {
        performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
        onClick()
    }
}

fun View.roundClip(radiusDp: Float) {
    val r = context.dpf(radiusDp)
    outlineProvider = object : ViewOutlineProvider() {
        override fun getOutline(view: View, outline: Outline) {
            outline.setRoundRect(0, 0, view.width, view.height, r)
        }
    }
    clipToOutline = true
}

fun staggerIn(group: ViewGroup, startDelay: Long = 0L) {
    val shift = group.context.dpf(28f)
    for (i in 0 until group.childCount) {
        val v = group.getChildAt(i)
        v.animate().cancel()
        v.alpha = 0f
        v.translationY = shift
        v.animate().alpha(1f).translationY(0f)
            .setStartDelay(startDelay + i * 65L)
            .setDuration(440)
            .setInterpolator(DecelerateInterpolator(1.7f))
            .start()
    }
}

fun countUp(t: TextView, to: Int, suffix: String, dur: Long = 1000) {
    ValueAnimator.ofInt(0, to).apply {
        duration = dur
        interpolator = DecelerateInterpolator(1.5f)
        addUpdateListener { t.text = "${it.animatedValue} $suffix" }
        start()
    }
}
