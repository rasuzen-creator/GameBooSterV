package uz.rasuzen.gamebooster

import android.app.Activity
import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.text.Editable
import android.text.InputType
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.widget.AbsListView
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridView
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView

/** Haqiqiy ikonkalar bilan o'yin tanlash oynasi. */
class GamePicker(private val act: Activity, private val onSaved: () -> Unit) {

    private val selected = HashSet<String>(Booster.games(act))
    private var all: List<AppEntry> = emptyList()
    private var shown: List<AppEntry> = emptyList()
    private var onlyGames = true
    private var query = ""
    private lateinit var adapter: BaseAdapter
    private lateinit var saveBtn: TextView
    private lateinit var loading: View
    private lateinit var chipGames: TextView
    private lateinit var chipAll: TextView

    private inner class Holder {
        val root = FrameLayout(act)
        val icon = ImageView(act)
        val label = act.tv("", 11f, C.TEXT, true)
        val check = act.tv("✓", 12f, C.DARK_TEXT, true)

        init {
            root.layoutParams = AbsListView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, act.dp(116))
            val col = act.vbox(0).apply {
                gravity = Gravity.CENTER
                setPadding(act.dp(6), act.dp(10), act.dp(6), act.dp(6))
            }
            icon.roundClip(14f)
            col.add(icon, act.dp(54), act.dp(54))
            label.gravity = Gravity.CENTER
            label.maxLines = 2
            label.ellipsize = TextUtils.TruncateAt.END
            col.add(label, MATCH, WRAP, t = 8)
            root.addView(col, FrameLayout.LayoutParams(MATCH, MATCH))
            check.gravity = Gravity.CENTER
            check.background = act.roundedBg(C.GREEN, 10f)
            val lpc = FrameLayout.LayoutParams(act.dp(20), act.dp(20), Gravity.TOP or Gravity.END)
            lpc.setMargins(0, act.dp(6), act.dp(6), 0)
            root.addView(check, lpc)
        }

        fun bind(e: AppEntry, sel: Boolean) {
            icon.setImageDrawable(e.icon)
            label.text = e.label
            root.background = act.roundedBg(
                if (sel) withAlpha(C.GREEN, 30) else C.SURFACE, 16f,
                if (sel) C.GREEN else C.STROKE, if (sel) 2 else 1
            )
            check.visibility = if (sel) View.VISIBLE else View.GONE
        }
    }

    private fun styleChips() {
        fun st(c: TextView, on: Boolean) {
            c.setTextColor(if (on) C.DARK_TEXT else C.MUTED)
            c.background = if (on) act.gradBg(C.GREEN, C.CYAN, 18f) else act.roundedBg(C.SURFACE2, 18f, C.STROKE, 1)
            c.setPadding(act.dp(16), act.dp(8), act.dp(16), act.dp(8))
        }
        st(chipGames, onlyGames)
        st(chipAll, !onlyGames)
    }

    private fun refilter() {
        val q = query.trim().lowercase()
        shown = all.filter {
            (q.isNotEmpty() || !onlyGames || it.isGame || it.pkg in selected) &&
                (q.isEmpty() || it.label.lowercase().contains(q))
        }
        adapter.notifyDataSetChanged()
        saveBtn.text = "Saqlash (${selected.size})"
    }

    fun show() {
        val d = Dialog(act, android.R.style.Theme_Material_NoActionBar)
        d.window?.apply {
            setBackgroundDrawable(ColorDrawable(C.BG))
            statusBarColor = C.BG
            navigationBarColor = C.BG
            setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        }
        val root = act.vbox(0).apply { setBackgroundColor(C.BG) }

        // sarlavha
        val head = act.hbox().apply { setPadding(act.dp(18), act.dp(18), act.dp(18), act.dp(8)) }
        val close = act.tv("✕", 20f, C.MUTED, true).apply { setPadding(0, act.dp(4), act.dp(16), act.dp(4)) }
        close.setOnClickListener { d.dismiss() }
        head.add(close, WRAP, WRAP)
        val titles = act.vbox(0)
        titles.add(act.tv("O'yinlarni tanlang", 22f, C.TEXT, true), WRAP, WRAP)
        titles.add(act.tv("Booster bilan ochiladigan o'yinlar", 12f, C.MUTED), WRAP, WRAP, t = 3)
        head.add(titles, 0, WRAP, weight = 1f)
        root.add(head)

        // qidiruv
        val search = EditText(act).apply {
            hint = "🔍  O'yin yoki ilova nomi"
            setHintTextColor(C.MUTED)
            setTextColor(C.TEXT)
            textSize = 15f
            isSingleLine = true
            inputType = InputType.TYPE_CLASS_TEXT
            background = act.roundedBg(C.SURFACE2, 16f, C.STROKE, 1)
            setPadding(act.dp(16), act.dp(12), act.dp(16), act.dp(12))
        }
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                query = s?.toString() ?: ""
                if (::adapter.isInitialized) refilter()
            }
        })
        root.add(search, l = 18, r = 18, t = 4)

        // filtr chiplari
        val chips = act.hbox()
        chipGames = act.tv("🎮  O'yinlar", 13f, C.TEXT, true)
        chipAll = act.tv("📱  Hammasi", 13f, C.TEXT, true)
        chipGames.setOnClickListener { onlyGames = true; styleChips(); refilter() }
        chipAll.setOnClickListener { onlyGames = false; styleChips(); refilter() }
        chips.add(chipGames, WRAP, WRAP, r = 8)
        chips.add(chipAll, WRAP, WRAP)
        styleChips()
        root.add(chips, l = 18, r = 18, t = 12, b = 6)

        // setka
        val grid = GridView(act).apply {
            numColumns = 3
            horizontalSpacing = act.dp(10)
            verticalSpacing = act.dp(10)
            stretchMode = GridView.STRETCH_COLUMN_WIDTH
            setPadding(act.dp(18), act.dp(8), act.dp(18), act.dp(8))
            clipToPadding = false
            selector = ColorDrawable(Color.TRANSPARENT)
            isVerticalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
        }
        adapter = object : BaseAdapter() {
            override fun getCount() = shown.size
            override fun getItem(position: Int): Any = shown[position]
            override fun getItemId(position: Int) = position.toLong()
            override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
                val e = shown[position]
                val h: Holder
                val v: View
                if (convertView == null) {
                    h = Holder()
                    v = h.root
                    v.tag = h
                } else {
                    v = convertView
                    h = convertView.tag as Holder
                }
                h.bind(e, e.pkg in selected)
                return v
            }
        }
        grid.adapter = adapter
        grid.setOnItemClickListener { _, v, pos, _ ->
            val e = shown[pos]
            if (!selected.remove(e.pkg)) selected.add(e.pkg)
            (v.tag as? Holder)?.bind(e, e.pkg in selected)
            v.animate().scaleX(0.9f).scaleY(0.9f).setDuration(80).withEndAction {
                v.animate().scaleX(1f).scaleY(1f).setDuration(180).start()
            }.start()
            saveBtn.text = "Saqlash (${selected.size})"
        }

        loading = ProgressBar(act)
        val gridHost = FrameLayout(act)
        gridHost.addView(grid, FrameLayout.LayoutParams(MATCH, MATCH))
        gridHost.addView(loading, FrameLayout.LayoutParams(act.dp(44), act.dp(44), Gravity.CENTER))
        root.add(gridHost, MATCH, 0, weight = 1f)

        // saqlash paneli
        saveBtn = act.pill("Saqlash (${selected.size})", C.GREEN, C.CYAN, C.DARK_TEXT, 16f)
        saveBtn.pressable {
            Booster.saveGames(act, selected)
            onSaved()
            d.dismiss()
        }
        val bottom = act.vbox(act.dp(16)).apply { setBackgroundColor(C.SURFACE) }
        bottom.add(saveBtn, MATCH, WRAP)
        root.add(bottom)

        d.setContentView(root)
        root.translationY = act.resources.displayMetrics.heightPixels.toFloat()
        d.show()
        root.animate().translationY(0f).setDuration(340).setInterpolator(DecelerateInterpolator(2f)).start()

        Thread {
            val apps = Booster.loadApps(act)
            act.runOnUiThread {
                all = apps
                if (apps.none { it.isGame }) onlyGames = false
                styleChips()
                loading.visibility = View.GONE
                refilter()
            }
        }.start()
    }
}
