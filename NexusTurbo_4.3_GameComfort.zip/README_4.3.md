# NexusTurbo 4.3 - Game Comfort Update

Included:
- Touch Guard: overlay becomes touch-through for 45 seconds; controls are temporarily blocked while game touch passes.
- Low-load overlay: pauses the Choreographer FPS callback and uses slower polling; FPS shown as unavailable while this mode is enabled.
- Battery Gaming mode: same low-load monitoring behavior, without changing screen brightness or system power settings.
- Recording presets: Low (854px/24fps/1Mbps), Balanced (1280px/30fps/2.5Mbps), High (1600px/30fps/5Mbps); devices with <=3.5GB RAM are capped to <=960px/24fps/1.8Mbps.
- Auto-stop recording checks every 15 seconds for <500MB free storage, battery <=10% while not charging, battery temperature >=45C, or configurable recording duration (default 30 min, stored 30 min).
- 20 center-marker reticle styles with a separate touch-through overlay.
- App dock lists launchable installed apps with actual Android-provided app icons. Selecting an app launches it as a normal app/activity.

Limitations:
- Android does not let a third-party app embed arbitrary installed app UIs inside its own overlay. Floating/split window behavior depends on the app and device/OEM. The app dock is an overlay launcher, not an app-in-app virtual window.
- Touch Guard is a timed touch-through overlay, not a screen-wide touch-lock; it lasts 45 seconds and restores controls automatically.
- Battery Gaming reduces NexusTurbo's own polling/animation workload. It does not force system-level CPU/GPU modes or change brightness.
- The center marker is cosmetic and is not an aim-assist, does not read game content, and may be disallowed by some games' rules.
- APK build not verified in this environment; run GitHub Actions to compile and install-test.
