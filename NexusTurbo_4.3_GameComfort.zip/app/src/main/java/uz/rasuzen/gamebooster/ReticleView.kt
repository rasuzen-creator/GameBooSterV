package uz.rasuzen.gamebooster

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.view.View

/** Lightweight, touch-through center marker. Pure drawing, no bitmap/assets. */
class ReticleView(context: Context) : View(context) {
    var styleIndex = 0
        set(value) { field = value.coerceIn(0, 19); invalidate() }
    var enabledMarker = false
        set(value) { field = value; visibility = if (value) VISIBLE else GONE; invalidate() }
    var markerColor = 0xFF40E0D0.toInt()
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = context.dpf(2f); strokeCap = Paint.Cap.ROUND }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val r = context.dpf(12f)
    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        if (!enabledMarker) return
        val x = width / 2f; val y = height / 2f; val d = context.dpf(18f); val gap = context.dpf(4f)
        p.color = markerColor; fill.color = markerColor
        p.strokeWidth = context.dpf(2f)
        when (styleIndex) {
            0 -> { c.drawLine(x-d,y,x-gap,y,p); c.drawLine(x+gap,y,x+d,y,p); c.drawLine(x,y-d,x,y-gap,p); c.drawLine(x,y+gap,x,y+d,p); c.drawCircle(x,y,context.dpf(2f),fill) }
            1 -> c.drawCircle(x,y,context.dpf(4f),p)
            2 -> { c.drawCircle(x,y,d,p); c.drawCircle(x,y,context.dpf(2f),fill) }
            3 -> { c.drawLine(x-d,y-d,x+d,y+d,p); c.drawLine(x-d,y+d,x+d,y-d,p) }
            4 -> { c.drawLine(x-d,y,x+d,y,p); c.drawLine(x,y-d,x,y+d,p) }
            5 -> { c.drawCircle(x,y,d,p); c.drawLine(x-d,y,x+d,y,p); c.drawLine(x,y-d,x,y+d,p) }
            6 -> { c.drawRect(x-d,y-d,x+d,y+d,p); c.drawCircle(x,y,context.dpf(2f),fill) }
            7 -> { c.drawLine(x-d,y-d,x-d/2,y-d,p); c.drawLine(x+d/2,y-d,x+d,y-d,p); c.drawLine(x+d,y-d,x+d,y-d/2,p); c.drawLine(x+d,y+d/2,x+d,y+d,p); c.drawLine(x+d,y+d,x+d/2,y+d,p); c.drawLine(x-d/2,y+d,x-d,y+d,p); c.drawLine(x-d,y+d,x-d,y+d/2,p); c.drawLine(x-d,y-d/2,x-d,y-d,p) }
            8 -> { c.drawCircle(x,y,d,p); c.drawCircle(x,y,d/2,p) }
            9 -> { c.drawLine(x-d,y,x-d/2,y,p); c.drawLine(x+d/2,y,x+d,y,p); c.drawLine(x,y-d,x,y-d/2,p); c.drawLine(x,y+d/2,x,y+d,p) }
            10 -> { c.drawCircle(x,y,d,p); c.drawLine(x-d,y,x-d/2,y,p); c.drawLine(x+d/2,y,x+d,y,p); c.drawLine(x,y-d,x,y-d/2,p); c.drawLine(x,y+d/2,x,y+d,p) }
            11 -> { c.drawLine(x-d,y-d,x+d,y+d,p); c.drawLine(x-d,y+d,x+d,y-d,p); c.drawCircle(x,y,context.dpf(2f),fill) }
            12 -> { val path=Path().apply { moveTo(x,y-d); lineTo(x+d,y); lineTo(x,y+d); lineTo(x-d,y); close() }; c.drawPath(path,p) }
            13 -> { c.drawCircle(x,y,context.dpf(3f),fill); c.drawCircle(x,y,d,p) }
            14 -> { c.drawLine(x-d,y,x-d/3,y,p); c.drawLine(x+d/3,y,x+d,y,p); c.drawLine(x,y-d,x,y-d/3,p); c.drawLine(x,y+d/3,x,y+d,p); c.drawCircle(x,y,context.dpf(5f),p) }
            15 -> { c.drawArc(x-d,y-d,x+d,y+d,45f,90f,false,p); c.drawArc(x-d,y-d,x+d,y+d,225f,90f,false,p); c.drawArc(x-d,y-d,x+d,y+d,135f,90f,false,p); c.drawArc(x-d,y-d,x+d,y+d,315f,90f,false,p) }
            16 -> { c.drawLine(x-d,y-d,x+d,y+d,p); c.drawLine(x-d,y+d,x+d,y-d,p); c.drawCircle(x,y,context.dpf(5f),p) }
            17 -> { c.drawRect(x-d,y-d,x+d,y+d,p); c.drawLine(x-d*1.4f,y,x+d*1.4f,y,p); c.drawLine(x,y-d*1.4f,x,y+d*1.4f,p) }
            18 -> { c.drawLine(x-d,y,x+d,y,p); c.drawLine(x,y-d,x,y+d,p); c.drawCircle(x,y,context.dpf(7f),p) }
            else -> { c.drawCircle(x,y,d,p); c.drawLine(x-d*1.3f,y,x+d*1.3f,y,p); c.drawLine(x,y-d*1.3f,x,y+d*1.3f,p) }
        }
    }
}
