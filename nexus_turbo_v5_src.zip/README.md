# Nexus Turbo v5 — yangi manba (namuna)

Bu asl APK'dan qayta yozilgan yangi manba. Asl kodingiz yo'q edi, shuning uchun
mavjud klasslarga to'g'ridan-to'g'ri ulab bo'lmaydi. Quyidagilar kiritilgan:

- SplashActivity: birinchi ishga tushirishda TURBO animatsiyasi, keyin yashil "Nexus Turbo"
  (Prefs orqali faqat bir marta chiqadi)
- BoostReport: BOOST oldin/keyin RAM va termal o'lchov
- ThermalMonitor: termal holatni real vaqtda kuzatish (Android 10+)
- FrameMeter: faqat shu ilovaning kadr vaqti (UI FPS)
- SessionAnalyzer: qoidaga asoslangan tavsiyalar
- CrosshairView: 5 xil crosshair uslubi, pulsatsiya animatsiyasi
- MeasureInfo: "qanday o'lchanadi" matni

Hali kiritilmagan:
- Overlay optimallashtirish (OverlayService manba kodi kerak)
- Game Mode API (chet ilova uchun o'qish API'si noaniq, qurilmada tekshirish kerak)
- Eski dizaynni butunlay almashtirish (mavjud layout va stillar kerak)

Ishga tushirish: Android Studio'da oching, Gradle sync qiling, qurilmada sinang.
Bu kod kompilyatsiya qilinmagan. Xatolar bo'lishi mumkin, ularni birgalikda tuzatamiz.

## Yangi qo'shilganlar (v5.1)
- 8 ta crosshair uslubi: nuqta, krest, bo'shliqli krest, doira, doira+nuqta, nuqtali doira, burchaklar, T shakl
- Qora kontur va glow (yorug' fonda ham ko'rinadi)
- Tanlash ekrani (CrosshairPickerActivity): har bir uslub jonli ko'rinadi
- BOOST bosilganda crosshair "tepish" animatsiyasi (kick)
