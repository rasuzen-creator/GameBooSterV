plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "uz.rasuzen.gamebooster"
    compileSdk = 34
    defaultConfig {
        applicationId = "uz.rasuzen.gamebooster"
        minSdk = 26
        targetSdk = 34
        versionCode = 7
        versionName = "5.0"
    }
    buildTypes {
        release { isMinifyEnabled = true; proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt")) }
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
dependencies { }
