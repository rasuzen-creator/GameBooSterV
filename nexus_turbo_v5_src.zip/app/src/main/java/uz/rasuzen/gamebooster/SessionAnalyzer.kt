package uz.rasuzen.gamebooster

data class SessionSample(val tMs: Long, val tempC: Float, val thermal: Int, val freeMb: Long)

// Qoidaga asoslangan tavsiyalar. Tizim ishlaydi deb va'da bermaydi, faqat o'lchovni izohlaydi.
object SessionAnalyzer {
    fun tips(samples: List<SessionSample>): List<String> {
        if (samples.size < 2) return listOf("Ma'lumot yetarli emas. Kamida bir necha daqiqa o'ynang.")
        val out = mutableListOf<String>()
        val maxTemp = samples.maxOf { it.tempC }
        if (maxTemp >= 42f) {
            out += "Harorat ${"%.1f".format(maxTemp)}°C ga yetdi. Uzoq o'yinda kadr tezligi pasayishi mumkin. Telefonni salqinroq joyga qo'ying."
        }
        if (samples.any { it.thermal >= 3 }) {
            out += "Og'ir termal cheklov qayd etildi. O'yin grafikasini pasaytirib ko'ring."
        }
        val minFree = samples.minOf { it.freeMb }
        if (minFree < 500) {
            out += "Bo'sh RAM ${minFree} MB gacha tushdi. Fon ilovalarni yoping."
        }
        if (out.isEmpty()) out += "Sessiya barqaror o'tdi."
        return out
    }
}
