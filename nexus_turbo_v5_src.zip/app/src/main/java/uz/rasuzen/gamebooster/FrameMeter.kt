package uz.rasuzen.gamebooster

import android.app.Activity
import android.os.Handler
import android.os.Looper
import android.view.FrameMetrics
import android.view.Window

// Faqat SHU ilovaning kadr vaqtini o'lchaydi. Boshqa o'yinning FPS'ini o'lchay olmaydi.
class FrameMeter(private val activity: Activity) {
    private var sumNs = 0L
    private var count = 0
    private val handler = Handler(Looper.getMainLooper())

    private val listener = Window.OnFrameMetricsAvailableListener { _, metrics, _ ->
        sumNs += metrics.getMetric(FrameMetrics.TOTAL_DURATION)
        count++
    }

    fun start() {
        activity.window.addOnFrameMetricsAvailableListener(listener, handler)
    }

    fun stop() {
        activity.window.removeOnFrameMetricsAvailableListener(listener)
    }

    fun reset() {
        sumNs = 0L
        count = 0
    }

    fun averageFrameMs(): Float = if (count == 0) 0f else sumNs / count / 1_000_000f

    fun uiFps(): Float {
        val ms = averageFrameMs()
        return if (ms == 0f) 0f else 1000f / ms
    }
}
