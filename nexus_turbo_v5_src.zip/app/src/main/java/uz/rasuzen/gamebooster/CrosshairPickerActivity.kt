package uz.rasuzen.gamebooster

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

// Crosshair tanlash ekrani: har bir uslub kartada jonli ko'rinadi
class CrosshairPickerActivity : Activity() {

    private val views = mutableMapOf<CrosshairStyle, CrosshairView>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val current = Prefs.crosshairStyle(this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#05070A"))
            setPadding(32, 64, 32, 32)
        }
        root.addView(TextView(this).apply {
            text = "Crosshair tanlang"
            setTextColor(Color.WHITE)
            textSize = 20f
            setPadding(0, 0, 0, 24)
        })

        val styles = CrosshairStyle.values()
        var row: LinearLayout? = null
        styles.forEachIndexed { i, style ->
            if (i % 2 == 0) {
                row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                root.addView(row)
            }
            row!!.addView(card(style, style == current),
                LinearLayout.LayoutParams(0, dp(150f).toInt(), 1f).apply { setMargins(8, 8, 8, 8) })
        }
        setContentView(root)
    }

    private fun card(style: CrosshairStyle, selected: Boolean): FrameLayout {
        val frame = FrameLayout(this).apply {
            setBackgroundResource(R.drawable.bg_card_round)
            isClickable = true
            setOnClickListener {
                Prefs.saveCrosshairStyle(this@CrosshairPickerActivity, style)
                finish()
            }
        }
        val xh = CrosshairView(this).apply {
            this.style = style
            sizeDp = 40f
            layoutParams = FrameLayout.LayoutParams(dp(80f).toInt(), dp(80f).toInt(), Gravity.CENTER)
        }
        views[style] = xh
        frame.addView(xh)
        frame.addView(TextView(this).apply {
            text = if (selected) "✓ ${style.title}" else style.title
            setTextColor(if (selected) Color.parseColor("#39FF88") else Color.parseColor("#B8C2CC"))
            textSize = 13f
            gravity = Gravity.CENTER_HORIZONTAL
        }, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM).apply { bottomMargin = dp(10f).toInt() })
        return frame
    }

    private fun dp(v: Float) = resources.displayMetrics.density * v
}
