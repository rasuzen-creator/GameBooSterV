package uz.rasuzen.gamebooster

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView

// ESLATMA: Bu namuna ekran. Mavjud MainActivity'ingizga shu bloklarni ko'chirib qo'shing.
class MainActivity : Activity() {

    private lateinit var result: TextView
    private lateinit var crosshair: CrosshairView
    private lateinit var thermalTv: TextView
    private lateinit var thermal: ThermalMonitor
    private lateinit var frames: FrameMeter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setBackgroundColor(Color.parseColor("#05070A"))
            setPadding(48, 96, 48, 48)
        }

        thermalTv = TextView(this).apply { setTextColor(Color.WHITE); textSize = 14f }
        result = TextView(this).apply { setTextColor(Color.parseColor("#B8C2CC")); textSize = 14f }

        crosshair = CrosshairView(this).apply {
            layoutParams = LinearLayout.LayoutParams(dp(120f).toInt(), dp(120f).toInt())
        }

        val boost = TextView(this).apply {
            text = "BOOST"
            setTextColor(Color.BLACK)
            setBackgroundColor(Color.parseColor("#39FF88"))
            textSize = 18f
            setPadding(48, 24, 48, 24)
            setOnClickListener { runBoost() }
        }
        val pick = TextView(this).apply {
            text = "Crosshair tanlash"
            setTextColor(Color.WHITE)
            textSize = 15f
            setPadding(0, 32, 0, 0)
            setOnClickListener { startActivity(Intent(this@MainActivity, CrosshairPickerActivity::class.java)) }
        }

        root.addView(thermalTv)
        root.addView(crosshair)
        root.addView(boost)
        root.addView(pick)
        root.addView(result)
        setContentView(root)

        thermal = ThermalMonitor(this) { status ->
            thermalTv.text = "Termal: ${ThermalMonitor.label(status)}"
        }
        frames = FrameMeter(this)
    }

    private fun runBoost() {
        crosshair.kick()
        val before = BoostReport.snapshot(this)
        // Bu yerda fon jarayonlarni to'xtatish logikasi (mavjud kodingizdan) chaqiriladi
        val after = BoostReport.snapshot(this)
        result.text = BoostReport.summarize(BoostComparison(before, after))
    }

    override fun onResume() {
        super.onResume()
        crosshair.style = Prefs.crosshairStyle(this)
        thermal.start()
        frames.start()
        crosshair.startPulse()
    }

    override fun onPause() {
        super.onPause()
        thermal.stop()
        frames.stop()
        crosshair.stopPulse()
    }

    private fun dp(v: Float) = resources.displayMetrics.density * v
}
