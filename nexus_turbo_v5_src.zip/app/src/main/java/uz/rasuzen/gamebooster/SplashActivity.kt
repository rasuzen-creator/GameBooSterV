package uz.rasuzen.gamebooster

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.TextView

class SplashActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Prefs.isSplashShown(this)) {
            openMain()
            return
        }
        Prefs.markSplashShown(this)

        val root = FrameLayout(this).apply { setBackgroundColor(Color.parseColor("#05070A")) }

        val turbo = TextView(this).apply {
            text = "TURBO"
            setTextColor(Color.WHITE)
            textSize = 64f
            typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
            gravity = Gravity.CENTER
            alpha = 0f
            scaleX = 0.4f
            scaleY = 0.4f
        }
        val nexus = TextView(this).apply {
            text = "Nexus Turbo"
            setTextColor(Color.parseColor("#39FF88"))
            textSize = 20f
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            gravity = Gravity.CENTER
            alpha = 0f
            translationY = 80f
        }
        root.addView(turbo, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.CENTER))
        root.addView(nexus, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.CENTER))
        setContentView(root)

        // 1) TURBO kattalashib, pishib chiqadi
        val turboIn = AnimatorSet().apply {
            playTogether(
                ObjectAnimator.ofFloat(turbo, View.ALPHA, 0f, 1f),
                ObjectAnimator.ofFloat(turbo, View.SCALE_X, 0.4f, 1f),
                ObjectAnimator.ofFloat(turbo, View.SCALE_Y, 0.4f, 1f)
            )
            duration = 700
            interpolator = OvershootInterpolator(1.4f)
        }
        // 2) "Nexus Turbo" yashil rangda sekin paydo bo'ladi
        val nexusIn = AnimatorSet().apply {
            playTogether(
                ObjectAnimator.ofFloat(nexus, View.ALPHA, 0f, 1f),
                ObjectAnimator.ofFloat(nexus, View.TRANSLATION_Y, 80f, 0f)
            )
            duration = 1400
            startDelay = 500
            interpolator = DecelerateInterpolator()
        }
        // 3) Hammasi yo'qoladi va asosiy ekran ochiladi
        val fadeOut = ObjectAnimator.ofFloat(root, View.ALPHA, 1f, 0f).apply {
            duration = 450
            startDelay = 800
        }

        AnimatorSet().apply {
            play(turboIn).with(nexusIn)
            play(fadeOut).after(nexusIn)
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) = openMain()
            })
            start()
        }

        // Xohlasa foydalanuvchi bosib o'tkazib yuboradi
        root.setOnClickListener { openMain() }
    }

    private fun openMain() {
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }
}
