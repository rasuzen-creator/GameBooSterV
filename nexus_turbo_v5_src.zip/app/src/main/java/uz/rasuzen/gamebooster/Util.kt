package uz.rasuzen.gamebooster

import android.content.Context
import android.util.TypedValue

fun Context.dp(v: Float): Float =
    TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, resources.displayMetrics)
