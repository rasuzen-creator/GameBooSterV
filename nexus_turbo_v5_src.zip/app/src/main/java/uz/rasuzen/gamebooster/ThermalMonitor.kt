package uz.rasuzen.gamebooster

import android.content.Context
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import java.util.concurrent.Executor

// Termal o'zgarishlarni tinglaydi (Android 10+). Pastroq versiyalarda hech narsa qilmaydi.
class ThermalMonitor(ctx: Context, private val onChange: (Int) -> Unit) {
    private val appCtx = ctx.applicationContext
    private val main = Handler(Looper.getMainLooper())
    private val executor = Executor { main.post(it) }
    private var listener: PowerManager.OnThermalStatusChangedListener? = null

    fun start() {
        if (Build.VERSION.SDK_INT < 29 || listener != null) return
        val l = PowerManager.OnThermalStatusChangedListener { onChange(it) }
        listener = l
        appCtx.getSystemService(PowerManager::class.java).addThermalStatusListener(executor, l)
    }

    fun stop() {
        if (Build.VERSION.SDK_INT < 29) return
        val l = listener ?: return
        appCtx.getSystemService(PowerManager::class.java).removeThermalStatusListener(l)
        listener = null
    }

    companion object {
        fun label(status: Int): String = when (status) {
            0 -> "Normal"
            1 -> "Yengil"
            2 -> "O'rta"
            3 -> "Og'ir"
            4 -> "Kritik"
            5 -> "Favqulodda"
            6 -> "O'chish"
            else -> "Noma'lum"
        }
    }
}
