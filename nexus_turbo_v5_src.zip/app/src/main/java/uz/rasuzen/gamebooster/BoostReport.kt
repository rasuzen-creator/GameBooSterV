package uz.rasuzen.gamebooster

import android.app.ActivityManager
import android.content.Context
import android.os.Build
import android.os.PowerManager

data class MemThermalSnapshot(
    val freeMb: Long,
    val totalMb: Long,
    val thermal: Int,
    val takenAt: Long
)

data class BoostComparison(val before: MemThermalSnapshot, val after: MemThermalSnapshot) {
    val freedMb: Long get() = after.freeMb - before.freeMb
    val thermalChanged: Boolean get() = after.thermal != before.thermal
}

// BOOST oldin/keyin haqiqiy o'lchov. Faqat tizim beradigan ma'lumotga asoslanadi.
object BoostReport {
    private const val MB = 1024L * 1024L

    fun snapshot(ctx: Context): MemThermalSnapshot {
        val am = ctx.getSystemService(ActivityManager::class.java)
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        val thermal = if (Build.VERSION.SDK_INT >= 29) {
            ctx.getSystemService(PowerManager::class.java).currentThermalStatus
        } else 0
        return MemThermalSnapshot(mi.availMem / MB, mi.totalMem / MB, thermal, System.currentTimeMillis())
    }

    fun summarize(c: BoostComparison): String {
        val lines = mutableListOf<String>()
        lines += when {
            c.freedMb >= 200 -> "Bo'sh RAM ${c.freedMb} MB ga oshdi."
            c.freedMb > 0 -> "Bo'sh RAM ${c.freedMb} MB ga oshdi. Farq kichik."
            else -> "Bo'sh RAM sezilarli o'zgarmadi. Android xotirani o'zi boshqaradi."
        }
        if (c.thermalChanged) {
            lines += "Termal holat: ${ThermalMonitor.label(c.before.thermal)} → ${ThermalMonitor.label(c.after.thermal)}"
        }
        return lines.joinToString("\n")
    }
}
