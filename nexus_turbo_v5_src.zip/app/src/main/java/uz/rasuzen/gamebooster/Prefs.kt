package uz.rasuzen.gamebooster

import android.content.Context

object Prefs {
    private const val NAME = "nexus_prefs"
    private const val KEY_SPLASH = "splash_shown"
    private const val KEY_XH_STYLE = "xh_style"

    private fun p(c: Context) = c.getSharedPreferences(NAME, Context.MODE_PRIVATE)

    // Splash faqat birinchi ishga tushirishda (ilova o'rnatilgandan keyin) chiqadi.
    fun isSplashShown(c: Context) = p(c).getBoolean(KEY_SPLASH, false)
    fun markSplashShown(c: Context) = p(c).edit().putBoolean(KEY_SPLASH, true).apply()

    fun crosshairStyle(c: Context): CrosshairStyle =
        CrosshairStyle.values().getOrElse(p(c).getInt(KEY_XH_STYLE, 0)) { CrosshairStyle.GAP_CROSS }
    fun saveCrosshairStyle(c: Context, s: CrosshairStyle) =
        p(c).edit().putInt(KEY_XH_STYLE, s.ordinal).apply()
}
