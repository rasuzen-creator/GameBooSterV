package uz.rasuzen.gamebooster

import android.animation.ObjectAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.cos
import kotlin.math.sin

enum class CrosshairStyle(val title: String) {
    DOT("Nuqta"),
    CROSS("Krest"),
    GAP_CROSS("Bo'shliqli krest"),
    CIRCLE("Doira"),
    CIRCLE_DOT("Doira + nuqta"),
    DOTTED_CIRCLE("Nuqtali doira"),
    BRACKETS("Burchaklar"),
    T_SHAPE("T shakl")
}

class CrosshairView(context: Context) : View(context) {

    var style: CrosshairStyle = CrosshairStyle.GAP_CROSS
        set(value) { field = value; invalidate() }
    var color: Int = Color.parseColor("#39FF88")
        set(value) { field = value; invalidate() }
    var sizeDp: Float = 28f
        set(value) { field = value; invalidate() }
    var thicknessDp: Float = 2f
        set(value) { field = value; invalidate() }
    var gapDp: Float = 6f
        set(value) { field = value; invalidate() }
    // Qora kontur: yorug' fonda ham ko'rinishi uchun
    var outline: Boolean = true
        set(value) { field = value; invalidate() }
    // Yorug'lik (glow) effekti
    var glow: Boolean = true
        set(value) { field = value; invalidate() }

    // Animatsiya uchun: ObjectAnimator "pulseScale" xususiyatini o'zgartiradi
    var pulseScale: Float = 1f
        set(value) { field = value; invalidate() }

    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val outlineLine = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        color = Color.argb(190, 0, 0, 0)
    }
    private val outlineFill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.argb(190, 0, 0, 0)
    }
    private var pulse: ObjectAnimator? = null

    fun startPulse() {
        if (pulse != null) return
        pulse = ObjectAnimator.ofFloat(this, "pulseScale", 1f, 1.25f, 1f).apply {
            duration = 900
            repeatCount = ObjectAnimator.INFINITE
            interpolator = LinearInterpolator()
            start()
        }
    }

    fun stopPulse() {
        pulse?.cancel()
        pulse = null
        pulseScale = 1f
    }

    // O'q otilganda qisqa "tepish" effekti
    fun kick() {
        ObjectAnimator.ofFloat(this, "pulseScale", 1f, 1.4f, 1f).apply {
            duration = 180
            start()
        }
    }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val cx = width / 2f
        val cy = height / 2f
        val s = context.dp(sizeDp) * pulseScale / 2f
        val t = context.dp(thicknessDp)
        val g = context.dp(gapDp)
        val cd = t * 1.6f

        line.color = color
        line.strokeWidth = t
        fill.color = color
        if (glow) {
            line.setShadowLayer(context.dp(4f), 0f, 0f, color)
            fill.setShadowLayer(context.dp(4f), 0f, 0f, color)
        } else {
            line.clearShadowLayer()
            fill.clearShadowLayer()
        }

        if (outline) {
            outlineLine.strokeWidth = t + context.dp(2f)
            drawShape(c, outlineLine, outlineFill, cx, cy, s, g, t + context.dp(2f), cd + context.dp(1f))
        }
        drawShape(c, line, fill, cx, cy, s, g, t, cd)
    }

    private fun drawShape(
        c: Canvas, ln: Paint, fl: Paint,
        cx: Float, cy: Float, s: Float, g: Float, t: Float, cd: Float
    ) {
        when (style) {
            CrosshairStyle.DOT -> c.drawCircle(cx, cy, cd, fl)

            CrosshairStyle.CROSS -> {
                c.drawLine(cx - s, cy, cx + s, cy, ln)
                c.drawLine(cx, cy - s, cx, cy + s, ln)
            }

            CrosshairStyle.GAP_CROSS -> {
                c.drawLine(cx - s, cy, cx - g, cy, ln)
                c.drawLine(cx + g, cy, cx + s, cy, ln)
                c.drawLine(cx, cy - s, cx, cy - g, ln)
                c.drawLine(cx, cy + g, cx, cy + s, ln)
            }

            CrosshairStyle.CIRCLE -> c.drawCircle(cx, cy, s, ln)

            CrosshairStyle.CIRCLE_DOT -> {
                c.drawCircle(cx, cy, s, ln)
                c.drawCircle(cx, cy, cd, fl)
            }

            CrosshairStyle.DOTTED_CIRCLE -> {
                val dotR = t * 0.9f
                for (i in 0 until 12) {
                    val a = Math.toRadians(i * 30.0)
                    c.drawCircle(cx + (cos(a) * s).toFloat(), cy + (sin(a) * s).toFloat(), dotR, fl)
                }
                c.drawCircle(cx, cy, cd, fl)
            }

            CrosshairStyle.BRACKETS -> {
                val len = s * 0.5f
                for (sx in listOf(-1f, 1f)) {
                    for (sy in listOf(-1f, 1f)) {
                        val x0 = cx + sx * (s + g)
                        val y0 = cy + sy * (s + g)
                        c.drawLine(x0, y0, x0 - sx * len, y0, ln)
                        c.drawLine(x0, y0, x0, y0 - sy * len, ln)
                    }
                }
                c.drawCircle(cx, cy, cd, fl)
            }

            CrosshairStyle.T_SHAPE -> {
                c.drawLine(cx - s, cy - g / 2, cx + s, cy - g / 2, ln)
                c.drawLine(cx, cy - g / 2, cx, cy + s, ln)
            }
        }
    }
}
