package uz.rasuzen.gamebooster

// Ilova ichidagi shaffof "qanday o'lchanadi" matni.
object MeasureInfo {
    const val TEXT = """
Bo'sh RAM: Android ActivityManager.MemoryInfo orqali o'qiladi.
Harorat: PowerManager termal holati (Android 10+) yoki batareya harorati.
Kadr tezligi (UI FPS): faqat Nexus Turbo oynasining kadr vaqti. Bu o'yinning haqiqiy FPS'i emas.
Boshqa ilovalarning FPS va ishlashi bu ilova tomonidan o'lchanmaydi.
"""
}
