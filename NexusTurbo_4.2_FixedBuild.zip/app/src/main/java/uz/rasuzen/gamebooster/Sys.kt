package uz.rasuzen.gamebooster

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.Sensor
import android.hardware.SensorManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.GLES20
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.os.SystemClock
import android.util.DisplayMetrics
import android.view.WindowManager
import java.io.File
import java.net.InetSocketAddress
import java.net.Socket
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import kotlin.math.abs
import kotlin.math.roundToInt
import kotlin.math.sqrt

typealias InfoSections = List<Pair<String, List<Pair<String, String>>>>

object Sys {

    class Mem(val totalMb: Long, val availMb: Long) {
        val usedMb: Long get() = totalMb - availMb
        val usedPct: Float get() = if (totalMb > 0) usedMb * 100f / totalMb else 0f
        val freePct: Float get() = 100f - usedPct
    }

    class Batt(
        val level: Int, val tempC: Float, val charging: Boolean, val voltageMv: Int,
        val health: String, val tech: String, val status: String, val plugged: String, val currentMa: Int
    )

    class Readiness(val score: Int, val label: String, val c1: Int, val c2: Int, val tips: List<String>)

    fun mem(ctx: Context): Mem {
        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        return Mem(mi.totalMem / 1048576, mi.availMem / 1048576)
    }

    fun batt(ctx: Context): Batt {
        val b = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val lvl = b?.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) ?: 0
        val scale = b?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val pct = if (scale > 0) lvl * 100 / scale else lvl
        val temp = (b?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f
        val st = b?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val charging = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
        val status = when (st) {
            BatteryManager.BATTERY_STATUS_CHARGING -> "Zaryadlanmoqda"
            BatteryManager.BATTERY_STATUS_DISCHARGING -> "Zaryad sarflanmoqda"
            BatteryManager.BATTERY_STATUS_FULL -> "To'la"
            BatteryManager.BATTERY_STATUS_NOT_CHARGING -> "Zaryadlanmayapti"
            else -> "Noma'lum"
        }
        val health = when (b?.getIntExtra(BatteryManager.EXTRA_HEALTH, 0)) {
            BatteryManager.BATTERY_HEALTH_GOOD -> "Yaxshi"
            BatteryManager.BATTERY_HEALTH_OVERHEAT -> "Qizib ketgan"
            BatteryManager.BATTERY_HEALTH_DEAD -> "Ishdan chiqqan"
            BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE -> "Yuqori kuchlanish"
            BatteryManager.BATTERY_HEALTH_COLD -> "Sovuq"
            else -> "Noma'lum"
        }
        val plugged = when (b?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0)) {
            BatteryManager.BATTERY_PLUGGED_AC -> "Adapter"
            BatteryManager.BATTERY_PLUGGED_USB -> "USB"
            BatteryManager.BATTERY_PLUGGED_WIRELESS -> "Simsiz"
            else -> "Ulanmagan"
        }
        var cur = 0
        try {
            val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
            cur = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW)
            if (cur == Int.MIN_VALUE) cur = 0
        } catch (e: Throwable) {
        }
        val ma = if (abs(cur) > 20000) cur / 1000 else cur
        return Batt(
            pct, temp, charging, b?.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0) ?: 0,
            health, b?.getStringExtra(BatteryManager.EXTRA_TECHNOLOGY) ?: "-", status, plugged, ma
        )
    }

    fun storage(): Pair<Long, Long> {
        val s = StatFs(Environment.getDataDirectory().path)
        return s.totalBytes to s.availableBytes
    }

    fun readFile(path: String): String? = try {
        File(path).readText().trim()
    } catch (e: Throwable) {
        null
    }

    /** Har bir yadro uchun joriy chastota (MHz), o'qib bo'lmasa -1. */
    fun cpuCurMhz(): List<Int> {
        val n = Runtime.getRuntime().availableProcessors()
        return (0 until n).map { i ->
            val v = readFile("/sys/devices/system/cpu/cpu$i/cpufreq/scaling_cur_freq")?.toLongOrNull() ?: -1L
            if (v > 0) (v / 1000).toInt() else -1
        }
    }

    fun cpuMaxMhz(): List<Int> {
        val n = Runtime.getRuntime().availableProcessors()
        return (0 until n).map { i ->
            val v = readFile("/sys/devices/system/cpu/cpu$i/cpufreq/cpuinfo_max_freq")?.toLongOrNull() ?: -1L
            if (v > 0) (v / 1000).toInt() else -1
        }
    }

    /** Agar tizim ruxsat bersa, CPU haroratini qaytaradi. */
    fun cpuTemp(): Float? {
        for (i in 0..40) {
            val type = readFile("/sys/class/thermal/thermal_zone$i/type") ?: continue
            val l = type.lowercase()
            if (l.contains("cpu") || l.contains("soc") || l.contains("tsens") || l.contains("mtktscpu")) {
                val v = readFile("/sys/class/thermal/thermal_zone$i/temp")?.toFloatOrNull() ?: continue
                val t = if (v > 1000f) v / 1000f else v
                if (t in 10f..120f) return t
            }
        }
        return null
    }

    fun fmtMb(mb: Long): String =
        if (mb >= 1024) String.format(Locale.US, "%.1f GB", mb / 1024.0) else "$mb MB"

    fun fmtBytes(b: Long): String = String.format(Locale.US, "%.1f GB", b / 1073741824.0)

    fun readiness(ctx: Context): Readiness {
        val m = mem(ctx)
        val bt = batt(ctx)
        val (total, free) = storage()
        val ramS = (m.freePct * 3f).coerceIn(0f, 100f)
        val tempS = (100f - (bt.tempC - 32f) / 13f * 100f).coerceIn(0f, 100f)
        val batS = if (bt.charging || bt.level >= 30) 100f else (bt.level * 3.3f).coerceIn(0f, 100f)
        val stPct = if (total > 0) free * 100f / total else 100f
        val stS = if (stPct >= 20f) 100f else (stPct * 5f).coerceIn(0f, 100f)
        val score = (ramS * 0.4f + tempS * 0.3f + batS * 0.15f + stS * 0.15f).roundToInt().coerceIn(0, 100)

        val tips = ArrayList<String>()
        if (m.freePct < 25f) tips.add("RAM: Bo'sh RAM kam (${m.freePct.roundToInt()}%). BOOST bosib fon ilovalarni tozalang.")
        if (bt.tempC >= 40f) tips.add("HARORAT: Telefon qizigan (${bt.tempC}°C). Qopqog'ini yechib, quvvatlashni to'xtating.")
        else if (bt.tempC >= 37f) tips.add("HARORAT: Harorat biroz baland (${bt.tempC}°C). Uzoq o'yinda FPS pasayishi mumkin.")
        if (!bt.charging && bt.level < 20) tips.add("BATAREYA: Batareya ${bt.level}%. Quvvat kam bo'lsa tizim ishlashni cheklaydi.")
        if (bt.charging && bt.tempC >= 36f) tips.add("ZARYAD: Zaryad paytida o'ynash qizdiradi. Imkon bo'lsa o'yindan oldin zaryadlab oling.")
        if (stPct < 10f) tips.add("XOTIRA: Xotira deyarli to'lgan (${stPct.roundToInt()}% bo'sh). O'yin yuklanishi sekinlashadi.")
        if (tips.isEmpty()) tips.add("STATUS: Hammasi joyida. Telefon o'yinga tayyor!")
        tips.add("TARMOQ: Online o'yinda Wi-Fi mobil internetdan barqarorroq. \"Asboblar\"da pingni tekshiring.")

        val label: String
        val a: Int
        val b: Int
        when {
            score >= 80 -> { label = "A'lo"; a = C.GREEN; b = C.CYAN }
            score >= 60 -> { label = "Yaxshi"; a = C.GREEN; b = C.YELLOW }
            score >= 40 -> { label = "O'rtacha"; a = C.ORANGE; b = C.YELLOW }
            else -> { label = "Past"; a = C.RED; b = C.ORANGE }
        }
        return Readiness(score, label, a, b, tips)
    }

    fun ping(host: String, port: Int = 443, timeoutMs: Int = 2500): Long = try {
        val s = Socket()
        val t0 = System.nanoTime()
        s.connect(InetSocketAddress(host, port), timeoutMs)
        val ms = (System.nanoTime() - t0) / 1_000_000
        s.close()
        ms
    } catch (e: Throwable) {
        -1L
    }

    private fun gpu(): Pair<String, String> = try {
        val d = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
        val v = IntArray(2)
        EGL14.eglInitialize(d, v, 0, v, 1)
        val attr = intArrayOf(
            EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT,
            EGL14.EGL_SURFACE_TYPE, EGL14.EGL_PBUFFER_BIT, EGL14.EGL_NONE
        )
        val cfgs = arrayOfNulls<EGLConfig>(1)
        val n = IntArray(1)
        EGL14.eglChooseConfig(d, attr, 0, cfgs, 0, 1, n, 0)
        val ctx = EGL14.eglCreateContext(d, cfgs[0], EGL14.EGL_NO_CONTEXT, intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE), 0)
        val surf = EGL14.eglCreatePbufferSurface(d, cfgs[0], intArrayOf(EGL14.EGL_WIDTH, 1, EGL14.EGL_HEIGHT, 1, EGL14.EGL_NONE), 0)
        EGL14.eglMakeCurrent(d, surf, surf, ctx)
        val r = GLES20.glGetString(GLES20.GL_RENDERER) ?: "Noma'lum"
        val ven = GLES20.glGetString(GLES20.GL_VENDOR) ?: "Noma'lum"
        EGL14.eglMakeCurrent(d, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT)
        EGL14.eglDestroySurface(d, surf)
        EGL14.eglDestroyContext(d, ctx)
        EGL14.eglTerminate(d)
        r to ven
    } catch (e: Throwable) {
        "Noma'lum" to "Noma'lum"
    }

    fun isRooted(): Boolean {
        val paths = listOf("/system/bin/su", "/system/xbin/su", "/sbin/su", "/su/bin/su", "/system/app/Superuser.apk", "/data/adb/magisk")
        return paths.any { File(it).exists() }
    }

    fun gpuName(): String = gpu().first

    fun deviceSections(ctx: Context): InfoSections {
        val out = ArrayList<Pair<String, List<Pair<String, String>>>>()
        val m = mem(ctx)
        val bt = batt(ctx)
        val (stTotal, stFree) = storage()

        out.add("QURILMA: Qurilma" to listOf(
            "Model" to Build.MODEL,
            "Ishlab chiqaruvchi" to Build.MANUFACTURER.replaceFirstChar { it.uppercase() },
            "Brend" to Build.BRAND.replaceFirstChar { it.uppercase() },
            "Kod nomi" to Build.DEVICE,
            "Platforma" to Build.BOARD,
            "Bootloader" to Build.BOOTLOADER,
            "Root" to if (isRooted()) "Ha" else "Yo'q"
        ))

        val maxF = cpuMaxMhz()
        val freqText = if (maxF.any { it > 0 }) {
            maxF.mapIndexed { i, f -> if (f > 0) "${i}: " + String.format(Locale.US, "%.2f GHz", f / 1000f) else "$i: -" }.joinToString("\n")
        } else "Tizim ruxsat bermadi"
        val chip = if (Build.VERSION.SDK_INT >= 31 && Build.SOC_MODEL.isNotBlank() && Build.SOC_MODEL != "unknown")
            "${Build.SOC_MANUFACTURER} ${Build.SOC_MODEL}" else Build.HARDWARE
        val cpuinfo = readFile("/proc/cpuinfo") ?: ""
        val hwLine = cpuinfo.lines().firstOrNull { it.startsWith("Hardware") }?.substringAfter(":")?.trim()
        out.add("TIZIM: Protsessor" to listOfNotNull(
            "Chipset" to chip,
            if (!hwLine.isNullOrBlank()) "Apparat" to hwLine else null,
            "Yadrolar soni" to "${Runtime.getRuntime().availableProcessors()}",
            "Arxitektura" to Build.SUPPORTED_ABIS.joinToString(", "),
            "Maks. chastotalar" to freqText
        ))

        val gp = gpu()
        val ai = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        out.add("O'YIN: Grafika (GPU)" to listOf(
            "GPU" to gp.first,
            "Ishlab chiqaruvchi" to gp.second,
            "OpenGL ES" to ai.deviceConfigurationInfo.glEsVersion
        ))

        val meminfo = readFile("/proc/meminfo") ?: ""
        val swapKb = meminfo.lines().firstOrNull { it.startsWith("SwapTotal") }
            ?.filter { it.isDigit() }?.toLongOrNull() ?: 0L
        out.add("RAM: Xotira" to listOf(
            "RAM jami" to fmtMb(m.totalMb),
            "RAM bo'sh" to "${fmtMb(m.availMb)} (${m.freePct.roundToInt()}%)",
            "Swap / zRAM" to if (swapKb > 0) fmtMb(swapKb / 1024) else "Yo'q",
            "Ichki xotira" to fmtBytes(stTotal),
            "Bo'sh joy" to fmtBytes(stFree)
        ))

        val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        @Suppress("DEPRECATION") val disp = wm.defaultDisplay
        val dm = DisplayMetrics()
        @Suppress("DEPRECATION") disp.getRealMetrics(dm)
        val inch = sqrt((dm.widthPixels / dm.xdpi).toDouble().let { it * it } + (dm.heightPixels / dm.ydpi).toDouble().let { it * it })
        val rates = disp.supportedModes.map { it.refreshRate.roundToInt() }.distinct().sorted()
        out.add("EKRAN: Ekran" to listOf(
            "O'lcham" to String.format(Locale.US, "%.1f dyuym", inch),
            "Piksel" to "${dm.widthPixels} × ${dm.heightPixels}",
            "Zichlik" to "${dm.densityDpi} dpi",
            "Hozirgi chastota" to "${disp.refreshRate.roundToInt()} Hz",
            "Qo'llab-quvvatlanadi" to rates.joinToString(" / ") { "$it Hz" }
        ))

        out.add("BATAREYA: Batareya" to listOf(
            "Daraja" to "${bt.level}%",
            "Holat" to bt.status,
            "Ulanish" to bt.plugged,
            "Harorat" to "${bt.tempC} °C",
            "Kuchlanish" to "${bt.voltageMv} mV",
            "Tok" to "${bt.currentMa} mA",
            "Salomatlik" to bt.health,
            "Texnologiya" to bt.tech
        ))

        val sm = ctx.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        val up = SystemClock.elapsedRealtime() / 1000
        out.add("Tizim" to listOf(
            "Android" to "${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})",
            "Xavfsizlik yangilanishi" to (Build.VERSION.SECURITY_PATCH ?: "-"),
            "Build" to Build.DISPLAY,
            "Kernel" to (System.getProperty("os.version") ?: "-"),
            "Sensorlar soni" to "${sm.getSensorList(Sensor.TYPE_ALL).size}",
            "Til" to Locale.getDefault().displayName,
            "Vaqt zonasi" to TimeZone.getDefault().id,
            "Yoqilganiga" to "${up / 3600} soat ${(up % 3600) / 60} daqiqa",
            "Build sanasi" to Date(Build.TIME).toString().substringBefore(" GMT").take(20)
        ))

        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = try { cm.getNetworkCapabilities(cm.activeNetwork) } catch (e: Throwable) { null }
        val net = when {
            caps == null -> "Ulanmagan"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Mobil internet"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Ethernet"
            else -> "Boshqa"
        }
        out.add("TARMOQ: Tarmoq" to listOf("Ulanish turi" to net))
        return out
    }
}
