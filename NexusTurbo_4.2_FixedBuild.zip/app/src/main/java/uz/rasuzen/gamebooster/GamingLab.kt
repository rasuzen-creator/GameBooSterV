package uz.rasuzen.gamebooster

import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.os.BatteryManager
import android.os.SystemClock
import android.net.TrafficStats
import org.json.JSONArray
import org.json.JSONObject
import java.net.InetSocketAddress
import java.net.Socket
import kotlin.math.abs
import kotlin.math.roundToInt

/** Session history and benchmarks. Metrics are explicitly estimates when Android cannot expose game internals. */
object GamingLab {
    data class Session(
        val pkg: String, val label: String, val started: Long, val durationMs: Long,
        val rx: Long?, val tx: Long?, val batteryUsed: Int?, val ramDeltaMb: Long?,
        val screenFpsAvg: Int?, val screenFpsMin: Int?, val maxTempC: Float?, val score: Int?
    )
    data class NetworkResult(val samples: List<Long>, val lossPct: Int, val avgMs: Long?, val jitterMs: Long?)
    data class Score(val total: Int, val screen: Int, val ram: Int, val thermal: Int, val battery: Int, val storage: Int, val network: Int, val label: String)

    private const val PREF = "nexus_gaming_lab"
    private fun prefs(ctx: Context) = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE)
    private fun battery(ctx: Context): Int = Sys.batt(ctx).level
    private fun ramUsed(ctx: Context): Long = Sys.mem(ctx).usedMb
    private fun uidTraffic(ctx: Context, pkg: String): Pair<Long?, Long?> = try {
        val ai = ctx.packageManager.getApplicationInfo(pkg, 0)
        TrafficStats.getUidRxBytes(ai.uid).takeIf { it >= 0 } to TrafficStats.getUidTxBytes(ai.uid).takeIf { it >= 0 }
    } catch (_: Throwable) { null to null }

    fun begin(ctx: Context, pkg: String) {
        val (rx, tx) = uidTraffic(ctx, pkg)
        val p = JSONObject().put("pkg", pkg).put("label", Booster.label(ctx, pkg))
            .put("started", System.currentTimeMillis()).put("elapsed", SystemClock.elapsedRealtime())
            .put("battery", battery(ctx)).put("ram", ramUsed(ctx))
            .put("rx", rx ?: -1).put("tx", tx ?: -1).put("fps", JSONArray()).put("temp", Sys.batt(ctx).tempC)
        prefs(ctx).edit().putString("pending", p.toString()).apply()
    }

    fun addSample(ctx: Context, screenFps: Int) {
        val raw = prefs(ctx).getString("pending", null) ?: return
        try {
            val p = JSONObject(raw); p.getJSONArray("fps").put(screenFps.coerceAtLeast(0))
            p.put("temp", maxOf(p.optDouble("temp", 0.0), Sys.batt(ctx).tempC.toDouble()))
            prefs(ctx).edit().putString("pending", p.toString()).apply()
        } catch (_: Throwable) {}
    }

    fun finish(ctx: Context) {
        val raw = prefs(ctx).getString("pending", null) ?: return
        try {
            val p = JSONObject(raw); val pkg = p.getString("pkg")
            val (rxNow, txNow) = uidTraffic(ctx, pkg)
            val fps = p.optJSONArray("fps") ?: JSONArray()
            val values = (0 until fps.length()).map { fps.optInt(it, 0) }.filter { it > 0 }
            val duration = (SystemClock.elapsedRealtime() - p.optLong("elapsed", SystemClock.elapsedRealtime())).coerceAtLeast(0)
            val bStart = p.optInt("battery", battery(ctx)); val bEnd = battery(ctx)
            val ramStart = p.optLong("ram", ramUsed(ctx)); val ramEnd = ramUsed(ctx)
            val rxStart = p.optLong("rx", -1).takeIf { it >= 0 }; val txStart = p.optLong("tx", -1).takeIf { it >= 0 }
            val rx = if (rxStart != null && rxNow != null) (rxNow - rxStart).coerceAtLeast(0) else null
            val tx = if (txStart != null && txNow != null) (txNow - txStart).coerceAtLeast(0) else null
            val thermal = p.optDouble("temp", Sys.batt(ctx).tempC.toDouble()).toFloat()
            val fpsAvg = values.takeIf { it.isNotEmpty() }?.average()?.roundToInt()
            val fpsMin = values.minOrNull()
            val score = sessionScore(fpsAvg, fpsMin, thermal, bStart - bEnd, duration)
            val record = JSONObject().put("pkg", pkg).put("label", p.optString("label", pkg))
                .put("started", p.optLong("started")).put("duration", duration)
                .put("rx", rx ?: -1).put("tx", tx ?: -1).put("battery", (bStart - bEnd).coerceAtLeast(0))
                .put("ramDelta", ramEnd - ramStart).put("fpsAvg", fpsAvg ?: -1).put("fpsMin", fpsMin ?: -1)
                .put("temp", thermal).put("score", score ?: -1)
            val all = JSONArray(prefs(ctx).getString("history", "[]") ?: "[]")
            val next = JSONArray().put(record)
            for (i in 0 until minOf(all.length(), 49)) next.put(all.getJSONObject(i))
            prefs(ctx).edit().putString("history", next.toString()).remove("pending").apply()
        } catch (_: Throwable) { prefs(ctx).edit().remove("pending").apply() }
    }

    fun duration(ms: Long): String {
        val mins = ms.coerceAtLeast(0) / 60_000
        val hrs = mins / 60
        return if (hrs > 0) "${hrs}h ${mins % 60}m" else "${mins}m"
    }

    fun pendingPackage(ctx: Context): String? = try { prefs(ctx).getString("pending", null)?.let { JSONObject(it).optString("pkg").takeIf { it.isNotBlank() } } } catch (_: Throwable) { null }
    fun history(ctx: Context): List<Session> = try {
        val a = JSONArray(prefs(ctx).getString("history", "[]") ?: "[]")
        (0 until a.length()).map { i -> val o = a.getJSONObject(i)
            Session(o.optString("pkg"), o.optString("label"), o.optLong("started"), o.optLong("duration"),
                o.optLong("rx", -1).takeIf { it >= 0 }, o.optLong("tx", -1).takeIf { it >= 0 },
                o.optInt("battery", -1).takeIf { it >= 0 }, o.optLong("ramDelta", Long.MIN_VALUE).takeIf { it != Long.MIN_VALUE },
                o.optInt("fpsAvg", -1).takeIf { it >= 0 }, o.optInt("fpsMin", -1).takeIf { it >= 0 },
                o.optDouble("temp", -1.0).toFloat().takeIf { it >= 0f }, o.optInt("score", -1).takeIf { it >= 0 })
        }
    } catch (_: Throwable) { emptyList() }
    fun historyFor(ctx: Context, pkg: String) = history(ctx).filter { it.pkg == pkg }
    fun clearHistory(ctx: Context) { prefs(ctx).edit().remove("history").apply() }

    private fun sessionScore(avg: Int?, min: Int?, temp: Float, batteryUsed: Int, duration: Long): Int? {
        if (duration < 60_000) return null
        val thermal = (100 - ((temp - 34f).coerceAtLeast(0f) * 4f)).coerceIn(0f, 100f)
        val batt = (100 - batteryUsed.coerceAtLeast(0) * 8).coerceIn(0, 100)
        // Overlay's Choreographer FPS is screen/overlay cadence, NOT the game's render FPS.
        val screenStability = if (avg == null || min == null) 65f else (100f - (avg - min).coerceAtLeast(0) * 1.2f).coerceIn(25f, 100f)
        return (screenStability * .35f + thermal * .35f + batt * .30f).roundToInt().coerceIn(0, 100)
    }

    fun benchmark(ctx: Context, network: NetworkResult, screenFps: Int): Score {
        val m = Sys.mem(ctx); val b = Sys.batt(ctx); val (total, free) = Sys.storage()
        val hz = try { (ctx.getSystemService(Context.WINDOW_SERVICE) as android.view.WindowManager).defaultDisplay.refreshRate.coerceAtLeast(30f) } catch (_: Throwable) { 60f }
        val screen = (screenFps / hz * 100f).coerceIn(0f, 100f).roundToInt()
        val ram = m.freePct.coerceIn(0f, 100f).roundToInt()
        val thermal = (100f - ((b.tempC - 32f).coerceAtLeast(0f) * 4f)).coerceIn(0f, 100f).roundToInt()
        val batteryScore = if (b.charging) 100 else (b.level * 1.1f).coerceIn(0f, 100f).roundToInt()
        val storagePct = if (total > 0) free * 100f / total else 100f
        val storageScore = (storagePct * 2f).coerceIn(0f, 100f).roundToInt()
        val networkScore = scoreNetwork(network)
        val totalScore = (screen * .20f + ram * .20f + thermal * .20f + batteryScore * .15f + storageScore * .10f + networkScore * .15f).roundToInt().coerceIn(0, 100)
        val label = when { totalScore >= 85 -> "O'yinga tayyor"; totalScore >= 70 -> "Yaxshi"; totalScore >= 50 -> "O'rtacha"; else -> "Tayyorlash tavsiya etiladi" }
        return Score(totalScore, screen, ram, thermal, batteryScore, storageScore, networkScore, label)
    }

    fun networkTest(host: String = "1.1.1.1", port: Int = 443, count: Int = 5): NetworkResult {
        val values = ArrayList<Long>(); var failed = 0
        repeat(count) {
            var s: Socket? = null
            try {
                s = Socket(); val start = System.nanoTime(); s.connect(InetSocketAddress(host, port), 2500)
                values.add((System.nanoTime() - start) / 1_000_000L)
            } catch (_: Throwable) { failed++ } finally { try { s?.close() } catch (_: Throwable) {} }
        }
        val avg = values.takeIf { it.isNotEmpty() }?.average()?.roundToInt()?.toLong()
        val jitter = values.takeIf { it.size >= 2 }?.let { xs ->
            xs.zipWithNext().map { abs(it.second - it.first) }.average().roundToInt().toLong()
        }
        return NetworkResult(values, (failed * 100f / count).roundToInt(), avg, jitter)
    }

    fun scoreNetwork(r: NetworkResult): Int {
        val latency = when { r.avgMs == null -> 0; r.avgMs < 40 -> 100; r.avgMs < 80 -> 85; r.avgMs < 150 -> 65; r.avgMs < 250 -> 40; else -> 20 }
        val loss = (100 - r.lossPct).coerceIn(0, 100)
        val jitter = when { r.jitterMs == null -> 60; r.jitterMs < 10 -> 100; r.jitterMs < 30 -> 80; r.jitterMs < 60 -> 55; else -> 25 }
        return (latency * .55f + loss * .25f + jitter * .20f).roundToInt()
    }

    fun foregroundSelected(ctx: Context, packages: Set<String>): String? {
        if (packages.isEmpty()) return null
        val usm = ctx.getSystemService(Context.USAGE_STATS_SERVICE) as? UsageStatsManager ?: return null
        return try {
            val now = System.currentTimeMillis(); val ev = usm.queryEvents(now - 60 * 60_000L, now); val event = UsageEvents.Event(); var current: String? = null
            while (ev.hasNextEvent()) { ev.getNextEvent(event); if (event.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND) current = event.packageName }
            current?.takeIf { it in packages }
        } catch (_: Throwable) { null }
    }
}
