package uz.rasuzen.gamebooster

import android.animation.ArgbEvaluator
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.SweepGradient
import android.graphics.Typeface
import android.view.MotionEvent
import android.view.View
import android.view.animation.DecelerateInterpolator
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/** Aylana shaklidagi animatsiyali ko'rsatkich (gauge). */
class GaugeView(ctx: Context) : View(ctx) {
    var value = 0f
        private set
    var bigText = ""
    var smallText = ""
    var caption = ""
    var scanning = false
        set(v) {
            field = v
            if (v) postInvalidateOnAnimation() else invalidate()
        }

    private var c1 = C.GREEN
    private var c2 = C.CYAN
    private var scanAngle = 0f
    private var shader: Shader? = null
    private var anim: ValueAnimator? = null
    private val rect = RectF()
    private val inner = RectF()

    private val trackP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; color = Color.parseColor("#1CFFFFFF")
    }
    private val progP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val glowP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val tickP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val dotP = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val scanP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val bigP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = C.TEXT; textAlign = Paint.Align.CENTER; typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
    }
    private val smallP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = C.MUTED; textAlign = Paint.Align.CENTER; typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    }

    fun setColors(a: Int, b: Int) {
        c1 = a; c2 = b
        rebuild()
        invalidate()
    }

    private fun rebuild() {
        if (width == 0) return
        shader = SweepGradient(width / 2f, height / 2f, intArrayOf(c1, c2, c2), floatArrayOf(0f, 0.75f, 1f))
    }

    fun animateTo(target: Float, dur: Long = 1300) {
        anim?.cancel()
        anim = ValueAnimator.ofFloat(value, target).apply {
            duration = dur
            interpolator = DecelerateInterpolator(1.8f)
            addUpdateListener { value = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    override fun onMeasure(w: Int, h: Int) {
        val s = MeasureSpec.getSize(w)
        setMeasuredDimension(s, s)
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        rebuild()
    }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val stroke = dpf(14f)
        val r = min(width, height) / 2f - dpf(24f)
        rect.set(cx - r, cy - r, cx + r, cy + r)

        // ticks
        tickP.strokeWidth = dpf(2f)
        val n = 40
        for (i in 0..n) {
            val a = Math.toRadians(135.0 + 270.0 * i / n)
            val lit = (i * 100f / n) <= value
            tickP.color = if (lit) withAlpha(c1, 230) else Color.parseColor("#22FFFFFF")
            val len = if (i % 5 == 0) dpf(9f) else dpf(5f)
            val r1 = r + dpf(16f)
            val r2 = r1 + len
            c.drawLine(
                cx + (cos(a) * r1).toFloat(), cy + (sin(a) * r1).toFloat(),
                cx + (cos(a) * r2).toFloat(), cy + (sin(a) * r2).toFloat(), tickP
            )
        }

        trackP.strokeWidth = stroke
        c.drawArc(rect, 135f, 270f, false, trackP)

        val sweep = 270f * (value / 100f).coerceIn(0f, 1f)
        if (sweep > 0.5f) {
            c.save()
            c.rotate(135f, cx, cy)
            glowP.color = c1
            glowP.strokeWidth = stroke * 2.3f
            glowP.alpha = 26
            c.drawArc(rect, 0f, sweep, false, glowP)
            glowP.color = c1
            glowP.strokeWidth = stroke * 1.6f
            glowP.alpha = 46
            c.drawArc(rect, 0f, sweep, false, glowP)
            progP.shader = shader
            progP.strokeWidth = stroke
            c.drawArc(rect, 0f, sweep, false, progP)
            c.restore()

            val ea = Math.toRadians(135.0 + sweep)
            c.drawCircle(cx + (cos(ea) * r).toFloat(), cy + (sin(ea) * r).toFloat(), stroke * 0.3f, dotP)
        }

        if (scanning) {
            scanAngle = (scanAngle + 7f) % 360f
            val ri = r - stroke * 1.9f
            inner.set(cx - ri, cy - ri, cx + ri, cy + ri)
            scanP.strokeWidth = dpf(4f)
            scanP.color = withAlpha(c2, 60)
            c.drawArc(inner, 0f, 360f, false, scanP)
            scanP.color = c2
            c.drawArc(inner, scanAngle, 70f, false, scanP)
            postInvalidateOnAnimation()
        }

        bigP.textSize = dpf(58f)
        c.drawText(if (bigText.isEmpty()) value.toInt().toString() else bigText, cx, cy + dpf(14f), bigP)
        smallP.textSize = dpf(15f)
        smallP.color = c1
        c.drawText(smallText, cx, cy + dpf(44f), smallP)
        smallP.textSize = dpf(11f)
        smallP.color = C.MUTED
        smallP.letterSpacing = 0.12f
        c.drawText(caption, cx, cy - dpf(48f), smallP)
        smallP.letterSpacing = 0f
    }
}

/** Yupqa gradient progress chiziq. */
class BarView(ctx: Context) : View(ctx) {
    var c1 = C.GREEN
    var c2 = C.CYAN
    private var v = 0f
    private var anim: ValueAnimator? = null
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val r = RectF()

    fun setPct(pct: Float, animate: Boolean = true) {
        val t = pct.coerceIn(0f, 100f)
        anim?.cancel()
        if (!animate) {
            v = t; invalidate(); return
        }
        anim = ValueAnimator.ofFloat(v, t).apply {
            duration = 800
            interpolator = DecelerateInterpolator()
            addUpdateListener { v = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    fun setColors(a: Int, b: Int) {
        c1 = a; c2 = b; invalidate()
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        p.shader = null
        p.color = Color.parseColor("#22FFFFFF")
        r.set(0f, 0f, w, h)
        c.drawRoundRect(r, h / 2, h / 2, p)
        val fw = w * v / 100f
        if (fw > 0f) {
            p.shader = LinearGradient(0f, 0f, w, 0f, c1, c2, Shader.TileMode.CLAMP)
            r.set(0f, 0f, max(fw, h), h)
            c.drawRoundRect(r, h / 2, h / 2, p)
            p.shader = null
        }
    }
}

/** Kichik chiziqli grafik (tarix). */
class GraphView(ctx: Context) : View(ctx) {
    var maxVal = 100f
    var lineColor = C.GREEN
        set(v) { field = v; invalidate() }
    var maxPoints = 40
    private val data = ArrayList<Float>()
    private val linePath = Path()
    private val fillPath = Path()
    private val lineP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeJoin = Paint.Join.ROUND; strokeCap = Paint.Cap.ROUND
    }
    private val fillP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val gridP = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#14FFFFFF"); strokeWidth = 1f }

    fun push(v: Float) {
        data.add(v)
        while (data.size > maxPoints) data.removeAt(0)
        invalidate()
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        for (i in 1..3) c.drawLine(0f, h * i / 4f, w, h * i / 4f, gridP)
        if (data.size < 2) return
        val step = w / (maxPoints - 1)
        val pad = dpf(4f)
        linePath.reset()
        fillPath.reset()
        val lastX = w
        val firstX = w - (data.size - 1) * step
        for (i in data.indices) {
            val x = w - (data.size - 1 - i) * step
            val y = h - pad - (data[i] / maxVal).coerceIn(0f, 1f) * (h - pad * 2)
            if (i == 0) {
                linePath.moveTo(x, y); fillPath.moveTo(x, y)
            } else {
                linePath.lineTo(x, y); fillPath.lineTo(x, y)
            }
        }
        fillPath.lineTo(lastX, h)
        fillPath.lineTo(firstX, h)
        fillPath.close()
        fillP.shader = LinearGradient(0f, 0f, 0f, h, withAlpha(lineColor, 110), withAlpha(lineColor, 0), Shader.TileMode.CLAMP)
        c.drawPath(fillPath, fillP)
        lineP.color = lineColor
        lineP.strokeWidth = dpf(2f)
        c.drawPath(linePath, lineP)
    }
}

/** Animatsiyali yoqish/o'chirish tugmasi. */
class ToggleView(ctx: Context) : View(ctx) {
    var checked = false
        private set
    var onChange: ((Boolean) -> Unit)? = null
    private var p = 0f
    private var anim: ValueAnimator? = null
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val ev = ArgbEvaluator()

    init {
        isClickable = true
        setOnClickListener {
            toggleTo(!checked, true)
            onChange?.invoke(checked)
        }
    }

    fun toggleTo(b: Boolean, animate: Boolean = true) {
        checked = b
        val t = if (b) 1f else 0f
        anim?.cancel()
        if (!animate) {
            p = t; invalidate(); return
        }
        anim = ValueAnimator.ofFloat(p, t).apply {
            duration = 240
            addUpdateListener { p = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(dp(54), dp(32))
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        paint.color = ev.evaluate(p, Color.parseColor("#2C3548"), C.GREEN) as Int
        rect.set(0f, 0f, w, h)
        c.drawRoundRect(rect, h / 2, h / 2, paint)
        val m = dpf(4f)
        val rad = h / 2 - m
        val cx = m + rad + p * (w - 2 * m - 2 * rad)
        paint.color = Color.WHITE
        c.drawCircle(cx, h / 2, rad, paint)
    }
}

/** Pulsatsiyalanuvchi asosiy BOOST tugmasi. */
class BoostButton(ctx: Context) : View(ctx) {
    var label = "BOOST"
        set(v) { field = v; invalidate() }
    var busy = false
        set(v) { field = v; invalidate() }
    private var pulse = 0f
    private val body = RectF()
    private val ring = RectF()
    private val clip = Path()
    private val fillP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ringP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val shineP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val textP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = C.DARK_TEXT; textAlign = Paint.Align.CENTER
        typeface = Typeface.create("sans-serif-medium", Typeface.BOLD); letterSpacing = 0.1f
    }
    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 1700
        repeatCount = ValueAnimator.INFINITE
        addUpdateListener { pulse = it.animatedValue as Float; invalidate() }
    }

    init { isClickable = true }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow(); anim.start()
    }

    override fun onDetachedFromWindow() {
        anim.cancel(); super.onDetachedFromWindow()
    }

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(resolveSize(dp(240), w), resolveSize(dp(78), h))
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> animate().scaleX(0.96f).scaleY(0.96f).setDuration(90).start()
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> animate().scaleX(1f).scaleY(1f).setDuration(170).start()
        }
        return super.onTouchEvent(e)
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val gl = dpf(9f)
        body.set(gl, gl, w - gl, h - gl)
        val rad = body.height() / 2f

        ringP.strokeWidth = dpf(2f)
        for (k in 0..1) {
            val ph = (pulse + k * 0.5f) % 1f
            ringP.color = withAlpha(C.GREEN, ((1f - ph) * 120).toInt())
            ring.set(body)
            ring.inset(-ph * gl, -ph * gl)
            c.drawRoundRect(ring, rad + ph * gl, rad + ph * gl, ringP)
        }

        fillP.shader = LinearGradient(body.left, 0f, body.right, 0f, C.GREEN, C.CYAN, Shader.TileMode.CLAMP)
        c.drawRoundRect(body, rad, rad, fillP)
        fillP.shader = null

        if (busy) {
            clip.reset()
            clip.addRoundRect(body, rad, rad, Path.Direction.CW)
            c.save()
            c.clipPath(clip)
            val bw = body.width() * 0.35f
            val x = body.left - bw + pulse * (body.width() + bw * 2)
            shineP.shader = LinearGradient(x, 0f, x + bw, 0f,
                intArrayOf(Color.TRANSPARENT, Color.parseColor("#80FFFFFF"), Color.TRANSPARENT), null, Shader.TileMode.CLAMP)
            c.drawRect(x, body.top, x + bw, body.bottom, shineP)
            c.restore()
        }

        textP.textSize = dpf(17f)
        val ty = h / 2f - (textP.descent() + textP.ascent()) / 2f
        c.drawText(label, w / 2f, ty, textP)
    }
}

/** Suzuvchi panel uchun FPS ko'rsatuvchi doira. */
class BubbleView(ctx: Context) : View(ctx) {
    var text = "--"
        set(v) { field = v; invalidate() }
    var accent = C.GREEN
        set(v) { field = v; invalidate() }
    private var pulse = 0f
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER; typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
    }
    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 1900
        repeatCount = ValueAnimator.INFINITE
        addUpdateListener { pulse = it.animatedValue as Float; invalidate() }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow(); anim.start()
    }

    override fun onDetachedFromWindow() {
        anim.cancel(); super.onDetachedFromWindow()
    }

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(dp(64), dp(64))
    }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val r = dpf(22f)
        p.style = Paint.Style.STROKE
        p.strokeWidth = dpf(2f)
        p.shader = null
        p.color = withAlpha(accent, ((1f - pulse) * 110).toInt())
        c.drawCircle(cx, cy, r + pulse * dpf(9f), p)
        p.style = Paint.Style.FILL
        p.shader = RadialGradient(cx, cy, r, intArrayOf(Color.parseColor("#24314A"), Color.parseColor("#0C111A")), null, Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, r, p)
        p.shader = null
        p.style = Paint.Style.STROKE
        p.strokeWidth = dpf(2f)
        p.color = accent
        c.drawCircle(cx, cy, r, p)
        tp.color = accent
        tp.textSize = dpf(15f)
        c.drawText(text, cx, cy + dpf(2f), tp)
        tp.color = C.MUTED
        tp.textSize = dpf(7.5f)
        c.drawText("FPS", cx, cy + dpf(12f), tp)
    }
}
