package uz.rasuzen.gamebooster

import android.app.AppOpsManager
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.net.TrafficStats
import android.os.Process
import android.provider.Settings
import java.io.File
import java.util.concurrent.TimeUnit

object GameStats {
    data class Snapshot(val todayMs: Long?, val rxBytes: Long?, val txBytes: Long?, val apkBytes: Long?, val running: Boolean?, val memoryMb: Long?)

    fun usageAccess(ctx: Context): Boolean {
        val ops = ctx.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        @Suppress("DEPRECATION")
        return ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName) == AppOpsManager.MODE_ALLOWED
    }

    fun openUsageAccess(ctx: Context) {
        ctx.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    fun snapshot(ctx: Context, pkg: String): Snapshot {
        val pm = ctx.packageManager
        val app = try { pm.getApplicationInfo(pkg, 0) } catch (_: Throwable) { return Snapshot(null,null,null,null,null,null) }
        var used: Long? = null
        var isForeground: Boolean? = null
        if (usageAccess(ctx)) {
            val usm = ctx.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
            val start = System.currentTimeMillis() - TimeUnit.DAYS.toMillis(1)
            used = usm.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, start, System.currentTimeMillis())
                ?.filter { it.packageName == pkg }?.sumOf { it.totalTimeInForeground } ?: 0L
            val last = usm.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, start, System.currentTimeMillis())
                ?.filter { it.packageName == pkg }?.maxByOrNull { it.lastTimeUsed }
            isForeground = last != null && System.currentTimeMillis() - last.lastTimeUsed < 90_000
        }
        val rx = TrafficStats.getUidRxBytes(app.uid).takeIf { it >= 0 }
        val tx = TrafficStats.getUidTxBytes(app.uid).takeIf { it >= 0 }
        val apk = File(app.sourceDir).length().takeIf { it > 0 }
        // Android 10+ limits access to other apps' process memory; don't fabricate it.
        return Snapshot(used, rx, tx, apk, isForeground, null)
    }

    fun time(ms: Long?): String = if (ms == null) "Ruxsat kerak" else {
        val h = ms / 3_600_000; val m = (ms / 60_000) % 60
        if (h > 0) "${h} soat ${m} daqiqa" else "$m daqiqa"
    }
    fun bytes(n: Long?): String = if (n == null) "Mavjud emas" else if (n < 1024L*1024) "${n/1024} KB" else "%.1f MB".format(n/1024f/1024f)
}
