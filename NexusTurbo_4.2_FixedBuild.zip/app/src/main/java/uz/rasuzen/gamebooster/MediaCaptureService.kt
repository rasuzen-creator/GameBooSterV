package uz.rasuzen.gamebooster

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.drawable.Icon
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.MediaStore
import android.util.DisplayMetrics
import android.view.WindowManager
import android.widget.Toast
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Low-impact screen capture. Recording is silent, capped to 720p/30fps and moderate bitrate. */
class MediaCaptureService : Service() {
    companion object {
        const val ACTION_CAPTURE = "uz.rasuzen.gamebooster.CAPTURE_SCREEN"
        const val ACTION_RECORD = "uz.rasuzen.gamebooster.START_RECORDING"
        const val ACTION_STOP_RECORD = "uz.rasuzen.gamebooster.STOP_RECORDING"
        const val EXTRA_RESULT_CODE = "projection_result"
        const val EXTRA_RESULT_DATA = "projection_data"
        @Volatile var isRecording = false
    }

    private val handler = Handler(Looper.getMainLooper())
    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var recorder: MediaRecorder? = null
    private var tempVideo: File? = null
    private var recordUri: Uri? = null
    private var recordAction = false
    private var stoppingProjection = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP_RECORD -> { stopRecordingAndSave(); stopSelf(); return START_NOT_STICKY }
            ACTION_CAPTURE, ACTION_RECORD -> {
                recordAction = intent.action == ACTION_RECORD
                startForegroundCompat()
                val code = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
                val data = if (Build.VERSION.SDK_INT >= 33) intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java) else @Suppress("DEPRECATION") intent.getParcelableExtra(EXTRA_RESULT_DATA)
                if (code == 0 || data == null) { stopSelf(); return START_NOT_STICKY }
                try {
                    val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                    projection = mgr.getMediaProjection(code, data)
                    projection?.registerCallback(object : MediaProjection.Callback() {
                        override fun onStop() {
                            if (!stoppingProjection) {
                                if (isRecording) stopRecordingAndSave() else { cleanup(); stopSelf() }
                            }
                        }
                    }, handler)
                    if (recordAction) beginRecording() else captureStill()
                } catch (e: Throwable) {
                    Toast.makeText(this, "Ekran capture boshlanmadi", Toast.LENGTH_SHORT).show()
                    cleanup(); stopSelf()
                }
            }
        }
        return START_NOT_STICKY
    }

    private fun startForegroundCompat() {
        val nm = getSystemService(NotificationManager::class.java)
        val channel = "nexus_capture"
        if (nm.getNotificationChannel(channel) == null) nm.createNotificationChannel(NotificationChannel(channel, "NexusTurbo Capture", NotificationManager.IMPORTANCE_LOW))
        val builder = Notification.Builder(this, channel)
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setContentTitle("NexusTurbo media capture")
            .setContentText(if (recordAction) "Ekran yozuvi davom etmoqda" else "Screenshot olinmoqda")
            .setOngoing(true)
        if (recordAction) {
            val stopIntent = Intent(this, MediaCaptureService::class.java).setAction(ACTION_STOP_RECORD)
            val stopPending = PendingIntent.getService(this, 44, stopIntent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            builder.addAction(Notification.Action.Builder(Icon.createWithResource(this, android.R.drawable.ic_media_pause), "Yozuvni to'xtatish", stopPending).build())
        }
        val notification = builder.build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(41, notification, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(41, notification)
    }

    private fun dimensions(): Pair<Int, Int> {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(metrics)
        // Recording is scaled down to reduce encoder/GPU overhead; screenshot keeps native resolution.
        val w = metrics.widthPixels
        val h = metrics.heightPixels
        return Pair(w, h)
    }

    private fun captureStill() {
        val (w, h) = dimensions()
        reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        display = projection?.createVirtualDisplay("NexusTurboScreenshot", w, h, resources.displayMetrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader?.surface, null, handler)
        handler.postDelayed({
            try {
                val image = reader?.acquireLatestImage() ?: throw IllegalStateException("Image unavailable")
                val plane = image.planes[0]
                val buffer = plane.buffer
                val pixelStride = plane.pixelStride
                val rowStride = plane.rowStride
                val rowPadding = rowStride - pixelStride * w
                val padded = Bitmap.createBitmap(w + rowPadding / pixelStride, h, Bitmap.Config.ARGB_8888)
                padded.copyPixelsFromBuffer(buffer)
                val bitmap = Bitmap.createBitmap(padded, 0, 0, w, h)
                padded.recycle(); image.close()
                saveBitmap(bitmap)
                bitmap.recycle()
                Toast.makeText(this, "Screenshot NexusTurbo papkasiga saqlandi", Toast.LENGTH_SHORT).show()
            } catch (_: Throwable) {
                Toast.makeText(this, "Screenshot saqlanmadi. Himoyalangan ekran bo'lishi mumkin.", Toast.LENGTH_LONG).show()
            } finally { cleanup(); stopSelf() }
        }, 420)
    }

    private fun saveBitmap(bitmap: Bitmap) {
        val name = "NexusTurbo_${stamp()}.jpg"
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, name)
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            if (Build.VERSION.SDK_INT >= 29) put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/NexusTurbo")
        }
        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: throw IllegalStateException("MediaStore insert failed")
        contentResolver.openOutputStream(uri)?.use { bitmap.compress(Bitmap.CompressFormat.JPEG, 92, it) } ?: throw IllegalStateException("Output unavailable")
    }

    private fun beginRecording() {
        val (screenW, screenH) = dimensions()
        // Preserve orientation and use a max 720p surface to avoid heavy encoding while gaming.
        val totalRamMb = try { Sys.mem(this).totalMb } catch (_: Throwable) { 0 }
        val longEdgeLimit = if (totalRamMb in 1..3500) 960f else 1280f
        val targetBitrate = if (totalRamMb in 1..3500) 1_800_000 else 3_000_000
        val scale = minOf(1f, longEdgeLimit / maxOf(screenW, screenH)).coerceAtLeast(0.25f)
        val w = ((screenW * scale).toInt() / 2) * 2
        val h = ((screenH * scale).toInt() / 2) * 2
        val file = File(cacheDir, "nt_record_${System.currentTimeMillis()}.mp4")
        tempVideo = file
        try {
            val mr = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else @Suppress("DEPRECATION") MediaRecorder()
            recorder = mr
            mr.setVideoSource(MediaRecorder.VideoSource.SURFACE)
            mr.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            mr.setVideoEncoder(MediaRecorder.VideoEncoder.H264)
            mr.setVideoSize(w.coerceAtLeast(2), h.coerceAtLeast(2))
            mr.setVideoFrameRate(30)
            mr.setVideoEncodingBitRate(targetBitrate)
            mr.setOutputFile(file.absolutePath)
            mr.prepare()
            display = projection?.createVirtualDisplay("NexusTurboRecording", w, h, resources.displayMetrics.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, mr.surface, null, handler)
            mr.start()
            isRecording = true
            Toast.makeText(this, "Yozuv boshlandi · ${longEdgeLimit.toInt()}px gacha / 30 FPS · ovozsiz", Toast.LENGTH_LONG).show()
        } catch (e: Throwable) {
            isRecording = false
            try { recorder?.release() } catch (_: Throwable) {}
            recorder = null
            cleanup(); stopSelf()
            Toast.makeText(this, "Video yozishni boshlash imkonsiz", Toast.LENGTH_LONG).show()
        }
    }

    private fun stopRecordingAndSave() {
        if (!isRecording) { cleanup(); return }
        isRecording = false
        try { recorder?.stop() } catch (_: Throwable) {}
        try { recorder?.reset(); recorder?.release() } catch (_: Throwable) {}
        recorder = null
        display?.release(); display = null
        stoppingProjection = true
        try { projection?.stop() } catch (_: Throwable) {}
        projection = null
        stoppingProjection = false
        val file = tempVideo
        if (file == null || !file.exists() || file.length() < 1024) {
            file?.delete()
            tempVideo = null
            stopSelf()
            return
        }
        try {
            val name = "NexusTurbo_${stamp()}.mp4"
            val values = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, name)
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                if (Build.VERSION.SDK_INT >= 29) put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/NexusTurbo")
            }
            val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values) ?: throw IllegalStateException()
            contentResolver.openOutputStream(uri)?.use { out -> file.inputStream().use { input -> input.copyTo(out, 1024 * 1024) } }
            file.delete()
            Toast.makeText(this, "Video Movies/NexusTurbo papkasiga saqlandi", Toast.LENGTH_LONG).show()
        } catch (_: Throwable) {
            file.delete()
            Toast.makeText(this, "Video saqlashda xatolik", Toast.LENGTH_LONG).show()
        }
        tempVideo = null
        stopSelf()
    }

    private fun stamp() = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())

    private fun cleanup() {
        isRecording = false
        try { display?.release() } catch (_: Throwable) {}
        display = null
        try { reader?.close() } catch (_: Throwable) {}
        reader = null
        try { recorder?.release() } catch (_: Throwable) {}
        recorder = null
        stoppingProjection = true
        try { projection?.stop() } catch (_: Throwable) {}
        projection = null
        stoppingProjection = false
        tempVideo?.let { if (it.exists() && !recordAction) it.delete() }
        tempVideo = null
    }

    override fun onDestroy() { cleanup(); super.onDestroy() }
}
