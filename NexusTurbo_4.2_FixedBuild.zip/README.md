# NexusTurbo 4.1 — Complete Gaming Assistant

Android/Kotlin project (Android 8.0+, API 26+; built with compile SDK 34 and Java 17).

## Included
- Gaming overlay with Neon/Minimal/Light themes, drag-and-snap, compact bubble, system stats, screen callback FPS estimate and low-FPS warnings.
- Selected game library and per-app statistics view.
- Usage Access-based optional Auto Game Detection: the overlay is shown for selected apps while detected foreground; requires Usage Access and Draw-over-other-apps permissions.
- Game session history when a game is launched from NexusTurbo: elapsed time, app UID traffic deltas if exposed, battery delta, system RAM delta, temperature sample, overlay callback FPS avg/min and session score.
- 100-point readiness benchmark combining screen callback cadence, free RAM, battery, thermal, storage and TCP network stability.
- Network stability test (TCP connection latency samples, average, jitter estimate and failed connection percentage).
- Session history clear control.
- Overlay opacity presets (100/90/75%), 30-second optional auto-collapse, and warning history.

## Limitations / honest measurements
- Overlay callback FPS is the overlay/screen cadence, not the game's renderer FPS. Android stock apps cannot read another game's render FPS reliably without device-specific APIs, root, or special access.
- Android limits third-party apps from reading another app's exact RAM use, battery consumption and full storage footprint. Per-app traffic may be unavailable on some devices. Missing values are shown as unavailable rather than fabricated.
- The benchmark is a readiness score, not a promise of FPS gain or a GPU benchmark. TCP latency is not ICMP ping and varies by host/route.
- Android does not allow ordinary apps to force-stop another app. Emergency Home moves the game away from foreground; it does not force-kill it.
- Screenshot/recording and touch-lock are not included in this build: reliable screen capture requires explicit MediaProjection consent and a separate capture flow; touch-lock needs a safe unlock mechanism to avoid trapping the user.
- Other-app crash/freeze detection cannot be reliably inferred from standard Usage Access. The session log records interruptions but does not claim to identify a crash reason.
- Auto detection needs Usage Access. Start/maintain overlay service using its foreground notification; the user can stop it.
- Session recording starts only when launching a selected game from NexusTurbo. Session stats may be incomplete if the service is disabled or the app/device is interrupted.

## Build APK with GitHub Actions
1. Upload this project to a GitHub repository (project files at repository root).
2. Push to `main` or `master`, or open Actions and run **Nexus Turbo Android Build**.
3. Download the `Nexus-Turbo-debug-apk` artifact from the workflow run.

No Gradle wrapper is included; workflow uses Gradle 8.7 and Java 17.

### NexusTurbo 4.2 media capture
The in-game overlay now includes screenshot and video controls. Screenshots are saved in Pictures/NexusTurbo. Screen recording is silent, H.264 MP4, up to 1280px long edge, 30fps and 3Mbps to reduce load. It requires the Android MediaProjection permission prompt. Rotation/landscape is supported; overlay width is bounded to avoid stretching. This feature has not been built on this machine (no Android SDK/Gradle available), so please run the workflow to validate APK compilation.
