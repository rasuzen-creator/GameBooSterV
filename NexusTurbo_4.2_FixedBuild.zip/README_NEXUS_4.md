# NexusTurbo 4.2 Gaming Assistant

## Added in 4.2
- Overlay screenshot capture button (MediaProjection permission flow).
- Silent screen recording from the overlay: H.264 MP4, up to 1280 px long edge, 30 FPS, 3 Mbps to limit gaming overhead.
- Recording start/stop controls in the overlay and Tools screen.
- Screenshot files saved under `Pictures/NexusTurbo`; recordings under `Movies/NexusTurbo`.
- Landscape orientation support and adaptive overlay width with bounded dimensions; UI controls avoid stretching.
- Version code 5 / version name 4.2.

## Important Android limitations
- Android requires the user to approve MediaProjection screen capture. Secure/protected surfaces may be black.
- Recording is silent and may still add heat or affect frame pacing; lower resolution/bitrate is chosen to reduce overhead, not guarantee zero lag.
- Screenshot uses native display resolution and can momentarily allocate a large bitmap.
- The project has not been built on this environment because Android SDK/Gradle are not installed. Run the GitHub Actions workflow or `gradle assembleDebug` with Android SDK installed to validate.
