package uz.rasuzen.gamebooster

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.res.Configuration
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.Icon
import android.net.TrafficStats
import android.os.Build
import android.os.Handler
import android.os.Vibrator
import android.os.VibrationEffect
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.text.format.DateFormat
import android.view.Choreographer
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.ScrollView
import android.widget.Toast
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.roundToInt
import android.animation.ValueAnimator

/** O'yin ustida suzib turadigan "Mod Menu" uslubidagi monitoring paneli. */
class OverlayService : Service() {

    companion object {
        @Volatile
        var running = false
        const val ACTION_STOP = "uz.rasuzen.gamebooster.STOP"
        private const val CH = "overlay"
        private const val NID = 7
    }

    private lateinit var wm: WindowManager
    private var root: FrameLayout? = null
    private lateinit var lp: WindowManager.LayoutParams
    private lateinit var bubble: BubbleView
    private lateinit var panel: LinearLayout
    private lateinit var panelScroll: ScrollView
    private val handler = Handler(Looper.getMainLooper())

    private lateinit var fpsBig: TextView
    private lateinit var fpsSub: TextView
    private lateinit var fpsGraph: GraphView
    private lateinit var ramTv: TextView
    private lateinit var ramBar: BarView
    private lateinit var cpuTv: TextView
    private lateinit var tempTv: TextView
    private lateinit var batTv: TextView
    private lateinit var netTv: TextView
    private lateinit var clockTv: TextView
    private lateinit var msgTv: TextView
    private lateinit var recordButtonTv: TextView

    private var frames = 0
    private var expanded = false
    private var refreshHz = 60f
    private var lastRx = 0L
    private var lastTx = 0L
    private var warningAt = 0L
    private var autoDetectedPkg: String? = null
    private var opacityIndex = 0
    private val opacityLevels = intArrayOf(100, 90, 75)
    private var autoHideEnabled = false
    private val autoHideRunnable = Runnable { if (expanded) setExpanded(false) }
    private var themeIndex = 0
    private val metricTiles = ArrayList<LinearLayout>()

    private val frameCb = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            frames++
            if (running) Choreographer.getInstance().postFrameCallback(this)
        }
    }

    private val tick = object : Runnable {
        override fun run() {
            update()
            handler.postDelayed(this, 1000)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val n = buildNotif()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NID, n)
        }
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (root == null) {
            if (!Settings.canDrawOverlays(this)) {
                stopSelf()
                return START_NOT_STICKY
            }
            createOverlay()
            running = true
            Choreographer.getInstance().postFrameCallback(frameCb)
            handler.postDelayed(tick, 1000)
        }
        return START_NOT_STICKY
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (root != null) {
            val available = resources.displayMetrics.widthPixels - dp(16)
            val width = min(dp(330), available.coerceAtLeast(dp(250)))
            val height = min(dp(480), (resources.displayMetrics.heightPixels - dp(16)).coerceAtLeast(dp(180)))
            panel.layoutParams = ScrollView.LayoutParams(width, WRAP)
            panelScroll.layoutParams = FrameLayout.LayoutParams(width, height)
            lp.x = lp.x.coerceIn(0, max(0, resources.displayMetrics.widthPixels - width))
            try { wm.updateViewLayout(root, lp) } catch (_: Throwable) {}
        }
    }

    override fun onDestroy() {
        running = false
        handler.removeCallbacksAndMessages(null)
        try {
            Choreographer.getInstance().removeFrameCallback(frameCb)
        } catch (e: Throwable) {
        }
        try {
            root?.let { wm.removeView(it) }
        } catch (e: Throwable) {
        }
        root = null
        super.onDestroy()
    }

    private fun buildNotif(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CH) == null) {
            nm.createNotificationChannel(NotificationChannel(CH, "Game Booster", NotificationManager.IMPORTANCE_LOW))
        }
        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        val stopPi = PendingIntent.getService(this, 1, Intent(this, OverlayService::class.java).setAction(ACTION_STOP), flags)
        val openPi = PendingIntent.getActivity(this, 2, Intent(this, MainActivity::class.java), flags)
        return Notification.Builder(this, CH)
            .setContentTitle("Game Booster")
            .setContentText("Mod Menu paneli faol")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentIntent(openPi)
            .setOngoing(true)
            .addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel), "To'xtatish", stopPi
                ).build()
            )
            .build()
    }

    // ---------------------------------------------------------------- UI

    private fun tile(title: String, valueTv: TextView, extra: View? = null): LinearLayout {
        val t = vbox(dp(10)).apply { background = roundedBg(Color.parseColor("#1A2233"), 12f, C.STROKE, 1) }
        t.add(tv(title, 9f, C.MUTED, true).apply { letterSpacing = 0.1f })
        t.add(valueTv, WRAP, WRAP, t = 3)
        if (extra != null) t.add(extra, MATCH, dp(4), t = 6)
        metricTiles.add(t)
        return t
    }

    private fun valueTv(): TextView = tv("--", 14f, C.TEXT, true)

    @SuppressLint("ClickableViewAccessibility")
    private fun createOverlay() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        themeIndex = getSharedPreferences("nexus_overlay", MODE_PRIVATE).getInt("theme", 0)
        opacityIndex = getSharedPreferences("nexus_overlay", MODE_PRIVATE).getInt("opacity", 0).coerceIn(0, 2)
        autoHideEnabled = getSharedPreferences("nexus_overlay", MODE_PRIVATE).getBoolean("auto_hide", false)
        @Suppress("DEPRECATION")
        refreshHz = wm.defaultDisplay.refreshRate

        lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(6)
            y = dp(120)
        }

        val frame = FrameLayout(this)

        bubble = BubbleView(this)
        frame.addView(bubble, FrameLayout.LayoutParams(WRAP, WRAP))
        drag(bubble) { setExpanded(true) }

        // ---- panel
        metricTiles.clear()
        panel = vbox(dp(14)).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.parseColor("#F0141B29"), Color.parseColor("#F00B0F17"))
            ).apply {
                cornerRadius = dpf(20f)
                setStroke(dp(1), withAlpha(C.GREEN, 110))
            }
            visibility = View.GONE
        }

        val header = hbox()
        header.add(tv("NEXUSTURBO  /  GAME HUD", 11f, C.GREEN, true).apply { letterSpacing = 0.14f }, 0, WRAP, weight = 1f)
        val minimize = tv("—", 16f, C.MUTED, true).apply { setPadding(dp(12), dp(2), dp(4), dp(2)) }
        minimize.setOnClickListener { setExpanded(false) }
        header.add(minimize, WRAP, WRAP)
        panel.add(header, b = 10)
        drag(header, null)

        // FPS row
        val fpsRow = hbox()
        val fpsCol = vbox(0)
        fpsBig = tv("--", 34f, C.GREEN, true)
        fpsSub = tv("EKRAN FPS", 9f, C.MUTED, true).apply { letterSpacing = 0.12f }
        fpsCol.add(fpsBig, WRAP, WRAP)
        fpsCol.add(fpsSub, WRAP, WRAP, t = 2)
        fpsRow.add(fpsCol, dp(84), WRAP)
        fpsGraph = GraphView(this).apply { maxVal = max(refreshHz, 60f) * 1.1f }
        fpsRow.add(fpsGraph, 0, dp(52), weight = 1f)
        panel.add(fpsRow, b = 10)

        ramTv = valueTv(); ramBar = BarView(this)
        cpuTv = valueTv(); tempTv = valueTv(); batTv = valueTv(); netTv = valueTv(); clockTv = valueTv()

        val r1 = hbox()
        r1.add(tile("RAM", ramTv, ramBar), 0, WRAP, r = 4, weight = 1f)
        r1.add(tile("CPU CHASTOTA", cpuTv), 0, WRAP, l = 4, weight = 1f)
        panel.add(r1, b = 8)
        val r2 = hbox()
        r2.add(tile("HARORAT", tempTv), 0, WRAP, r = 4, weight = 1f)
        r2.add(tile("BATAREYA", batTv), 0, WRAP, l = 4, weight = 1f)
        panel.add(r2, b = 8)
        val r3 = hbox()
        r3.add(tile("TARMOQ", netTv), 0, WRAP, r = 4, weight = 1f)
        r3.add(tile("VAQT", clockTv), 0, WRAP, l = 4, weight = 1f)
        panel.add(r3, b = 10)

        val actions = hbox()
        val bBoost = pill("BOOST", C.GREEN, C.CYAN, C.DARK_TEXT, 12f).apply { setPadding(dp(8), dp(10), dp(8), dp(10)) }
        val bDnd = pill("DND", C.PURPLE, C.CYAN, Color.WHITE, 12f).apply { setPadding(dp(8), dp(10), dp(8), dp(10)) }
        val bStop = pill("YOPISH", C.RED, C.ORANGE, Color.WHITE, 12f).apply { setPadding(dp(8), dp(10), dp(8), dp(10)) }
        bBoost.pressable { doBoost() }
        bDnd.pressable { toggleDnd() }
        bStop.pressable { stopSelf() }
        actions.add(bBoost, 0, WRAP, r = 4, weight = 1f)
        actions.add(bDnd, 0, WRAP, l = 2, r = 2, weight = 1f)
        actions.add(bStop, 0, WRAP, l = 4, weight = 1f)
        panel.add(actions)

        // Capture controls: launch permission flow in the app; labels remain compact in both orientations.
        val captureRow = hbox()
        val screenshot = ghostPill("SCREENSHOT", C.CYAN, 10f)
        screenshot.pressable { launchCaptureActivity(MediaCaptureService.ACTION_CAPTURE) }
        val record = ghostPill(if (MediaCaptureService.isRecording) "STOP REC" else "REC VIDEO", C.RED, 10f)
        recordButtonTv = record
        record.pressable {
            launchCaptureActivity(if (MediaCaptureService.isRecording) MediaCaptureService.ACTION_STOP_RECORD else MediaCaptureService.ACTION_RECORD)
        }
        captureRow.add(screenshot, 0, WRAP, r = 4, weight = 1f)
        captureRow.add(record, 0, WRAP, l = 4, weight = 1f)
        panel.add(captureRow, t = 6)

        val themeButton = pill("TEMA: NEON  /  O'ZGARTIRISH", C.CYAN, C.PURPLE, Color.WHITE, 10f)
        themeButton.pressable { cycleTheme() }
        panel.add(themeButton, t = 8)
        val homeButton = ghostPill("EMERGENCY HOME  /  O'YINDAN CHIQISH", C.RED, 10f)
        homeButton.pressable { returnHome() }
        panel.add(homeButton, t = 6)
        val extras = hbox()
        val opacityButton = ghostPill("OPACITY: ${opacityLevels[opacityIndex]}%", C.CYAN, 9f)
        opacityButton.pressable { cycleOpacity(opacityButton) }
        val autoHideButton = ghostPill(if (autoHideEnabled) "AUTO-HIDE: ON" else "AUTO-HIDE: OFF", C.PURPLE, 9f)
        autoHideButton.pressable { toggleAutoHide(autoHideButton) }
        extras.add(opacityButton, 0, WRAP, r = 4, weight = 1f)
        extras.add(autoHideButton, 0, WRAP, l = 4, weight = 1f)
        panel.add(extras, t = 6)

        msgTv = tv("", 11f, C.YELLOW, true).apply { gravity = Gravity.CENTER; visibility = View.GONE }
        panel.add(msgTv, t = 8)

        val available = resources.displayMetrics.widthPixels - dp(16)
        val panelWidth = min(dp(330), available.coerceAtLeast(dp(250)))
        val availableHeight = resources.displayMetrics.heightPixels - dp(16)
        val panelHeight = min(dp(480), availableHeight.coerceAtLeast(dp(180)))
        panelScroll = ScrollView(this).apply {
            isFillViewport = false
            isVerticalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
        }
        panelScroll.addView(panel, ScrollView.LayoutParams(panelWidth, WRAP))
        frame.addView(panelScroll, FrameLayout.LayoutParams(panelWidth, panelHeight))
        panelScroll.visibility = View.GONE
        root = frame
        wm.addView(frame, lp)
        applyThemePalette()
        applyOpacity()
    }

    private fun cycleOpacity(button: TextView) {
        opacityIndex = (opacityIndex + 1) % opacityLevels.size
        getSharedPreferences("nexus_overlay", MODE_PRIVATE).edit().putInt("opacity", opacityIndex).apply()
        button.text = "OPACITY: ${opacityLevels[opacityIndex]}%"
        applyOpacity()
    }

    private fun applyOpacity() {
        val alpha = opacityLevels[opacityIndex] / 100f
        bubble.alpha = alpha
        panel.alpha = alpha
    }

    private fun toggleAutoHide(button: TextView) {
        autoHideEnabled = !autoHideEnabled
        getSharedPreferences("nexus_overlay", MODE_PRIVATE).edit().putBoolean("auto_hide", autoHideEnabled).apply()
        button.text = if (autoHideEnabled) "AUTO-HIDE: ON" else "AUTO-HIDE: OFF"
        if (autoHideEnabled && expanded) scheduleAutoHide() else handler.removeCallbacks(autoHideRunnable)
        showMsg(if (autoHideEnabled) "Panel 30 soniyada yig'iladi" else "Auto-hide o'chirildi")
    }

    private fun scheduleAutoHide() {
        handler.removeCallbacks(autoHideRunnable)
        if (autoHideEnabled && expanded) handler.postDelayed(autoHideRunnable, 30_000)
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun drag(handle: View, onTap: (() -> Unit)?) {
        var sx = 0f
        var sy = 0f
        var ox = 0
        var oy = 0
        var moved = false
        handle.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - sx
                    val dy = e.rawY - sy
                    if (abs(dx) > dp(6) || abs(dy) > dp(6)) moved = true
                    if (moved) {
                        lp.x = (ox + dx).toInt()
                        lp.y = (oy + dy).toInt()
                        root?.let { wm.updateViewLayout(it, lp) }
                    }
                }
                MotionEvent.ACTION_UP -> if (!moved) onTap?.invoke() else snapToEdge()
            }
            true
        }
    }

    private fun snapToEdge() {
        val screenW = resources.displayMetrics.widthPixels
        val width = if (expanded) (panel.width.takeIf { it > 0 } ?: dp(290)) else dp(58)
        val target = if (lp.x + width / 2 < screenW / 2) dp(4) else max(0, screenW - width - dp(4))
        val from = lp.x
        ValueAnimator.ofInt(from, target).apply {
            duration = 220
            addUpdateListener { a -> lp.x = a.animatedValue as Int; root?.let { wm.updateViewLayout(it, lp) } }
            start()
        }
    }

    private fun cycleTheme() {
        themeIndex = (themeIndex + 1) % 3
        getSharedPreferences("nexus_overlay", MODE_PRIVATE).edit().putInt("theme", themeIndex).apply()
        applyThemePalette()
        showMsg(when(themeIndex) { 1 -> "MINIMAL tema"; 2 -> "LIGHT tema"; else -> "NEON tema" })
    }

    private fun applyThemePalette() {
        val light = themeIndex == 2
        metricTiles.forEach { it.background = roundedBg(if (light) Color.parseColor("#FFE2E8F0") else Color.parseColor("#1A2233"), 12f, if (light) Color.parseColor("#FFB7C4D5") else C.STROKE, 1) }
        fun tintTree(v: View) {
            if (v is TextView) {
                if (v.tag == null) v.tag = v.currentTextColor
                v.setTextColor(if (light) Color.parseColor("#FF263449") else (v.tag as? Int ?: C.TEXT))
            }
            if (v is ViewGroup) for (i in 0 until v.childCount) tintTree(v.getChildAt(i))
        }
        tintTree(panel)
        val colors = when(themeIndex) {
            1 -> intArrayOf(Color.parseColor("#F0161D28"), Color.parseColor("#F0121722"))
            2 -> intArrayOf(Color.parseColor("#F0F3F6FA"), Color.parseColor("#F0E9EEF5"))
            else -> intArrayOf(Color.parseColor("#F0141B29"), Color.parseColor("#F00B0F17"))
        }
        panel.background = GradientDrawable(GradientDrawable.Orientation.TL_BR, colors).apply {
            cornerRadius = dpf(20f); setStroke(dp(1), withAlpha(C.GREEN, 110))
        }
    }

    private fun returnHome() {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(intent)
        showMsg("O'yin fon rejimiga o'tkazildi. Android uni majburan yopishga ruxsat bermaydi.")
    }

    private fun criticalAlert(fps: Int) {
        val now = System.currentTimeMillis()
        if (now - warningAt < 10_000) return
        warningAt = now
        saveWarning(fps)
        if (fps <= 1) {
            showMsg("KRITIK: 1 FPS yoki past. O'yinni to'xtatish tavsiya etiladi.")
            bubble.animate().scaleX(1.18f).scaleY(1.18f).setDuration(180).withEndAction {
                bubble.animate().scaleX(1f).scaleY(1f).setDuration(180).start()
            }.start()
            try {
                if (Build.VERSION.SDK_INT >= 26) (getSystemService(VIBRATOR_SERVICE) as Vibrator).vibrate(VibrationEffect.createWaveform(longArrayOf(0, 260, 110, 260, 110, 500), -1))
            } catch (_: Throwable) {}
        } else {
            showMsg("OG'OHLANTIRISH: FPS 5 dan past. Ishlash pasaymoqda.")
        }
    }

    private fun saveWarning(fps: Int) {
        val prefs = getSharedPreferences("nexus_warning_history", MODE_PRIVATE)
        val current = prefs.getString("items", "") ?: ""
        val item = "${System.currentTimeMillis()}|$fps"
        val lines = (listOf(item) + current.lines().filter { it.isNotBlank() }).take(30)
        prefs.edit().putString("items", lines.joinToString("\n")).apply()
    }

    private fun setExpanded(e: Boolean) {
        expanded = e
        handler.removeCallbacks(autoHideRunnable)
        if (e) {
            val sw = resources.displayMetrics.widthPixels
            val measuredWidth = panel.width.takeIf { it > 0 } ?: dp(290)
            lp.x = lp.x.coerceIn(0, max(0, sw - measuredWidth))
            bubble.visibility = View.GONE
            panelScroll.visibility = View.VISIBLE
            panel.visibility = View.VISIBLE
            panel.pivotX = 0f
            panel.pivotY = 0f
            panel.alpha = 0f
            panel.scaleX = 0.82f
            panel.scaleY = 0.82f
            panel.animate().alpha(opacityLevels[opacityIndex] / 100f).scaleX(1f).scaleY(1f).setDuration(220).start()
        } else {
            panel.visibility = View.GONE
            panelScroll.visibility = View.GONE
            bubble.visibility = View.VISIBLE
        }
        root?.let { wm.updateViewLayout(it, lp) }
        if (e) scheduleAutoHide()
    }

    // ---------------------------------------------------------------- actions

    private fun launchCaptureActivity(action: String) {
        if (action == MediaCaptureService.ACTION_CAPTURE && MediaCaptureService.isRecording) {
            showMsg("Screenshot uchun avval video yozuvni to'xtating")
            return
        }
        val intent = Intent(this, MainActivity::class.java)
            .putExtra("nexus_capture_action", action)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        try { startActivity(intent) } catch (_: Throwable) { showMsg("Capture boshqaruvi ilovada ochilmadi") }
    }

    private fun showMsg(s: String) {
        msgTv.text = s
        msgTv.visibility = View.VISIBLE
        handler.postDelayed({ msgTv.visibility = View.GONE }, 4000)
    }

    private fun doBoost() {
        val before = Booster.availMb(this)
        Booster.kill(this, null)
        showMsg("Tozalanmoqda…")
        handler.postDelayed({
            val freed = (Booster.availMb(this) - before).coerceAtLeast(0)
            showMsg("~$freed MB bo'shatildi")
        }, 1200)
    }

    private fun toggleDnd() {
        if (!Booster.dndGranted(this)) {
            Toast.makeText(this, "DND ruxsati kerak: ilovani ochib, Asboblar bo'limida bering", Toast.LENGTH_LONG).show()
            return
        }
        val on = Booster.dndOn(this)
        Booster.setDnd(this, !on)
        showMsg(if (on) "DND o'chirildi" else "DND yoqildi")
    }

    // ---------------------------------------------------------------- stats

    private fun update() {
        // Usage Access bilan tanlangan o'yinni aniqlash (ixtiyoriy, foydalanuvchi yoqadi).
        if (Booster.flag(this, "auto_game_detect", false) && GameStats.usageAccess(this)) {
            val foreground = GamingLab.foregroundSelected(this, Booster.games(this))
            if (foreground != autoDetectedPkg) {
                autoDetectedPkg = foreground
                if (foreground != null) {
                    root?.visibility = View.VISIBLE
                    if (!expanded) setExpanded(true)
                    showMsg("O'yin aniqlandi: ${Booster.label(this, foreground)}")
                } else {
                    setExpanded(false)
                    root?.visibility = View.GONE
                }
            } else if (foreground != null) root?.visibility = View.VISIBLE
        } else {
            autoDetectedPkg = null
            root?.visibility = View.VISIBLE
        }

        // FPS — overlay/screen callback taxmini; bu game renderer FPS'i emas.
        val fps = frames
        frames = 0
        GamingLab.addSample(this, fps)
        val good = fps >= refreshHz * 0.9f
        val mid = fps >= refreshHz * 0.6f
        val col = if (good) C.GREEN else if (mid) C.ORANGE else C.RED
        bubble.text = "$fps"
        bubble.accent = col
        fpsBig.text = "$fps"
        fpsBig.setTextColor(col)
        fpsGraph.lineColor = col
        fpsGraph.push(fps.toFloat())
        if (fps < 5 && (!Booster.flag(this, "auto_game_detect", false) || autoDetectedPkg != null)) criticalAlert(fps)
        fpsSub.text = "EKRAN FPS · ${refreshHz.roundToInt()} Hz"

        if (::recordButtonTv.isInitialized) recordButtonTv.text = if (MediaCaptureService.isRecording) "STOP REC" else "REC VIDEO"
        if (!expanded) return

        val m = Sys.mem(this)
        ramTv.text = "${m.usedMb} / ${m.totalMb} MB"
        ramBar.setPct(m.usedPct)
        ramBar.setColors(if (m.usedPct > 85) C.RED else if (m.usedPct > 70) C.ORANGE else C.GREEN, C.CYAN)

        val f = Sys.cpuCurMhz().filter { it > 0 }
        cpuTv.text = if (f.isEmpty()) "—" else String.format(Locale.US, "%.2f GHz", f.max() / 1000f)

        val b = Sys.batt(this)
        val ct = Sys.cpuTemp()
        tempTv.text = if (ct != null) "${b.tempC}° · CPU ${ct.roundToInt()}°" else "${b.tempC} °C"
        tempTv.setTextColor(if (b.tempC >= 42) C.RED else if (b.tempC >= 38) C.ORANGE else C.TEXT)
        batTv.text = "${b.level}%" + (if (b.charging) " · CHARGING" else "") + (if (b.currentMa != 0) "  ${abs(b.currentMa)} mA" else "")

        val rx = TrafficStats.getTotalRxBytes()
        val tx = TrafficStats.getTotalTxBytes()
        if (lastRx > 0 && rx >= 0) {
            val d = (rx - lastRx) / 1024
            val u = (tx - lastTx) / 1024
            netTv.text = "↓${d} ↑${u} KB/s"
        } else netTv.text = "—"
        lastRx = rx
        lastTx = tx

        clockTv.text = DateFormat.format("HH:mm", System.currentTimeMillis()).toString()
    }
}
